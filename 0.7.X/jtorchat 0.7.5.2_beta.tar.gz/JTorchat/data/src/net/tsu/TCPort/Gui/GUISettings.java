package net.tsu.TCPort.Gui;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.*;


import net.tsu.TCPort.Config;
import net.tsu.TCPort.TCPort;

@SuppressWarnings("serial")
public class GUISettings extends JFrame {
//	private boolean hasBroadcast = false;
	
	public GUISettings() {
//		try {
//			Class.forName("net.tsu.TCPort.Broadcast.Broadcast");
//			hasBroadcast = true;
//		} catch (ClassNotFoundException e) {
//			// ignored
//		}
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		initComponents();
		textField1.setText(TCPort.profile_name);
		textField2.setText(TCPort.profile_text);
		textField4.setText(Config.SOCKS_PORT > 0 ? Config.SOCKS_PORT + "" : "");
		textField5.setText(Config.LOCAL_PORT > 0 ? Config.LOCAL_PORT + "" : "");
		textField6.setText((Config.us != null && Config.us.length() > 0) ? Config.us : "");
		textField7.setText(Config.sync);
		textField8.setText(Config.update);
		if (Config.alert == 1) { checkBox2.setSelected(true); } else { checkBox2.setSelected(false); }
		if (Config.loadTor == 1) { checkBox1.setSelected(true); } else { checkBox1.setSelected(false); }
		if (Config.buddyStart == 1) { checkBox3.setSelected(true); } else { checkBox3.setSelected(false); }
		if (Config.transferonstart == 1) { checkBox4.setSelected(true); } else { checkBox4.setSelected(false); }
		if (Config.pageactive == 1) { checkBox5.setSelected(true); } else { checkBox5.setSelected(false); }
		if (Config.updateStart == 1) { checkBox6.setSelected(true); } else { checkBox6.setSelected(false); }
		if (Config.visiblelog == 1) { checkBox7.setSelected(true); } else { checkBox7.setSelected(false); }
		if (Config.fulllog == 1) { checkBox8.setSelected(true); } else { checkBox8.setSelected(false); }
		if (Config.obfsproxy == 1) { checkBox9.setSelected(true); } else { checkBox9.setSelected(false); }
		if (Config.ClickableLinks == 1) { checkBox10.setSelected(true); } else { checkBox10.setSelected(false); }							
		
		this.addWindowListener(new WindowListener() {
            @Override
			public void windowClosed(WindowEvent e) {}
            @Override
			public void windowActivated(WindowEvent e) {}
            @Override
			public void windowClosing(WindowEvent e) {
        		dispose();
        		synchronized(this) {
        			this.notifyAll(); // tell anyone waiting on us that we're done
        		}
            }
            @Override
			public void windowDeactivated(WindowEvent e) {}
            @Override
			public void windowDeiconified(WindowEvent e) {}
            @Override
			public void windowIconified(WindowEvent e) {}
            @Override
			public void windowOpened(WindowEvent e) {}
        });
	}

	private void ok(ActionEvent e) {
		String name = textField1.getText();
		String prof = textField2.getText();
		String sync = textField7.getText();
		String update = textField8.getText();
		boolean alert = checkBox2.isSelected();
		boolean loadTor = checkBox1.isSelected();
		boolean buddyStart = checkBox3.isSelected();
		boolean updateStart = checkBox6.isSelected();
		boolean showlog = checkBox7.isSelected();
		boolean fulllog = checkBox8.isSelected();
		boolean file = checkBox4.isSelected();
		boolean page = checkBox5.isSelected();
		boolean obfsproxy = checkBox9.isSelected();
		boolean ClickableLinks = checkBox10.isSelected();
		
		int sp = -1, lp = -1;
		
		if (textField4.getText().length() != 0) {
			try {
				sp = Integer.parseInt(textField4.getText());
				if (sp < 1) {
					JOptionPane.showMessageDialog(null, textField4.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
					return;
				}
			} catch (NumberFormatException nfe) {
				JOptionPane.showMessageDialog(null, textField4.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		if (textField5.getText().length() != 0) {
			try {
				lp = Integer.parseInt(textField5.getText());
				if (lp < 1) {
					JOptionPane.showMessageDialog(null, textField5.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
					return;
				}
			} catch (NumberFormatException nfe) {
				JOptionPane.showMessageDialog(null, textField5.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		if (textField6.getText().length() == 16) {
			Config.us = textField6.getText(); // FIXME not fully checking the id
		} else if (textField6.getText().length() != 0) {
			JOptionPane.showMessageDialog(null, textField6.getText() + " is an invalid Id", "Invalid Id", JOptionPane.ERROR_MESSAGE);
			return;
		}
		Config.SOCKS_PORT = sp;
		Config.LOCAL_PORT = lp;
		Config.sync = sync;
		Config.update = update;
		if (alert) { Config.alert = 1; } else {Config.alert = 0; } ;
		if (loadTor) { Config.loadTor = 1; } else {Config.loadTor = 0; } ;
		if (buddyStart) { Config.buddyStart = 1; } else {Config.buddyStart = 0; } ;
		if (updateStart) { Config.updateStart = 1; } else {Config.updateStart = 0; } ;
		TCPort.profile_name = name;
		TCPort.profile_text = prof;
		if (file) { Config.transferonstart = 1; } else {Config.transferonstart = 0; } ;
		if (page) { Config.pageactive = 1; } else {Config.pageactive = 0; } ;
		if (showlog) { Config.visiblelog = 1; } else {Config.visiblelog = 0; } ;
		if (fulllog) { Config.fulllog = 1; } else {Config.fulllog = 0; } ;
		if (obfsproxy) { Config.obfsproxy = 1; } else {Config.obfsproxy = 0; } ;		
		if (ClickableLinks) { Config.ClickableLinks = 1; } else {Config.ClickableLinks = 0; } ;
		
		Config.prop.put("profile_name", name);
		Config.prop.put("profile_text", prof);
		Config.prop.put("SOCKS_PORT", Config.SOCKS_PORT + "");
		Config.prop.put("LOCAL_PORT", Config.LOCAL_PORT + "");
		Config.prop.put("ourId", Config.us == null ? "" : Config.us);
		Config.prop.put("sync", sync);
		Config.prop.put("update", update);
	    if (alert) { Config.prop.put("alert", 1 + ""); } else {Config.prop.put("alert", 0 + ""); } ;
	    if (loadTor) { Config.prop.put("loadPortableTor", 1 + ""); } else {Config.prop.put("loadTor", 0 + ""); } ;
	    if (buddyStart) { Config.prop.put("OnStartBuddySync", 1 + ""); } else {Config.prop.put("OnStartBuddySync", 0 + ""); } ;
	    if (updateStart) { Config.prop.put("OnStartUpdateCheck", 1 + ""); } else {Config.prop.put("OnStartUpdateCheck", 0 + ""); } ;
	    if (file) { Config.prop.put("transferonstart", 1 + ""); } else {Config.prop.put("transferonstart", 0 + ""); } ;
	    if (page) { Config.prop.put("pageactive", 1 + ""); } else {Config.prop.put("pageactive", 0 + ""); } ;
	    if (showlog) { Config.prop.put("OnStartLoggerDisplay", 1 + ""); } else {Config.prop.put("OnStartLoggerDisplay", 0 + ""); } ;
	    if (fulllog) { Config.prop.put("EnableFullLoggerMode", 1 + ""); } else {Config.prop.put("EnableFullLoggerMode", 0 + ""); } ;
	    if (obfsproxy) { Config.prop.put("obfsproxy", 1 + ""); } else {Config.prop.put("obfsproxy", 0 + ""); } ;
	    if (ClickableLinks) { Config.prop.put("ClickableLinks", 1 + ""); } else {Config.prop.put("ClickableLinks", 0 + ""); } ;

	    TCPort.sendMyInfo();
		try {
			Config.prop.store(new FileOutputStream(Config.CONFIG_DIR + "settings.ini"), null);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		
		dispose();
		synchronized(this) {
			this.notifyAll(); // tell anyone waiting on us that we're done
		}
	}

	public JTabbedPane getTabbedPane1() {
		return tabbedPane1;
	}

	private void update(ActionEvent e) {
		Config.nowstartupdate = textField8.getText();
		Config.allcheckupdate = 1;
	}

	private void sync(ActionEvent e) {
		Config.nowstart = textField7.getText();
	}


	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - jhgfdf jhgfc
		tabbedPane1 = new JTabbedPane();
		panel1 = new JPanel();
		label1 = new JLabel();
		textField1 = new JTextField();
		label2 = new JLabel();
		textField2 = new JTextField();
		checkBox2 = new JCheckBox();
		checkBox4 = new JCheckBox();
		checkBox5 = new JCheckBox();
		checkBox7 = new JCheckBox();
		checkBox8 = new JCheckBox();
		checkBox10 = new JCheckBox();
		panel2 = new JPanel();
		label4 = new JLabel();
		textField4 = new JTextField();
		label5 = new JLabel();
		textField5 = new JTextField();
		label6 = new JLabel();
		textField6 = new JTextField();
		checkBox1 = new JCheckBox();
		checkBox9 = new JCheckBox();
		label3 = new JLabel();
		label7 = new JLabel();
		panel3 = new JPanel();
		label8 = new JLabel();
		textField7 = new JTextField();
		button2 = new JButton();
		checkBox3 = new JCheckBox();
		panel4 = new JPanel();
		label9 = new JLabel();
		textField8 = new JTextField();
		button3 = new JButton();
		checkBox6 = new JCheckBox();
		button1 = new JButton();

		//======== this ========
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridBagLayout());
		((GridBagLayout)contentPane.getLayout()).columnWidths = new int[] {0, 0};
		((GridBagLayout)contentPane.getLayout()).rowHeights = new int[] {0, 0, 0};
		((GridBagLayout)contentPane.getLayout()).columnWeights = new double[] {1.0, 1.0E-4};
		((GridBagLayout)contentPane.getLayout()).rowWeights = new double[] {1.0, 0.0, 1.0E-4};

		//======== tabbedPane1 ========
		{

			//======== panel1 ========
			{

				panel1.setLayout(new GridBagLayout());
				((GridBagLayout)panel1.getLayout()).columnWidths = new int[] {0, 0, 0, 0};
				((GridBagLayout)panel1.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0, 0, 0, 0};
				((GridBagLayout)panel1.getLayout()).columnWeights = new double[] {0.0, 0.0, 0.0, 1.0E-4};
				((GridBagLayout)panel1.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

				//---- label1 ----
				label1.setText("Profile name: ");
				label1.setHorizontalAlignment(SwingConstants.RIGHT);
				panel1.add(label1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 10, 5, 5), 0, 0));

				//---- textField1 ----
				textField1.setPreferredSize(new Dimension(180, 28));
				panel1.add(textField1, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 0, 5, 15), 0, 0));

				//---- label2 ----
				label2.setText("Profile text: ");
				label2.setHorizontalAlignment(SwingConstants.RIGHT);
				panel1.add(label2, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- textField2 ----
				textField2.setPreferredSize(new Dimension(180, 28));
				panel1.add(textField2, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 15), 0, 0));

				//---- checkBox2 ----
				checkBox2.setText("alert on events");
				checkBox2.setPreferredSize(new Dimension(60, 18));
				checkBox2.setMinimumSize(new Dimension(30, 18));
				checkBox2.setSelected(true);
				panel1.add(checkBox2, new GridBagConstraints(1, 2, 2, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- checkBox4 ----
				checkBox4.setText("automatic File Transfer start");
				panel1.add(checkBox4, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- checkBox5 ----
				checkBox5.setText("page function");
				panel1.add(checkBox5, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- checkBox7 ----
				checkBox7.setText("show log on start");
				panel1.add(checkBox7, new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- checkBox8 ----
				checkBox8.setText("activate full log (fatal over time)");
				panel1.add(checkBox8, new GridBagConstraints(1, 6, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- checkBox10 ----
				checkBox10.setText("Clickable Links (open with broswer)");
				panel1.add(checkBox10, new GridBagConstraints(1, 7, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 0, 5), 0, 0));
			}
			tabbedPane1.addTab("General", panel1);


			//======== panel2 ========
			{
				panel2.setLayout(new GridBagLayout());
				((GridBagLayout)panel2.getLayout()).columnWidths = new int[] {0, 0, 0, 0};
				((GridBagLayout)panel2.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0, 30, 0, 0};
				((GridBagLayout)panel2.getLayout()).columnWeights = new double[] {0.0, 0.0, 0.0, 1.0E-4};
				((GridBagLayout)panel2.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

				//---- label4 ----
				label4.setText("* Tor socks port: ");
				label4.setHorizontalAlignment(SwingConstants.RIGHT);
				panel2.add(label4, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 10, 5, 5), 0, 0));

				//---- textField4 ----
				textField4.setPreferredSize(new Dimension(180, 28));
				panel2.add(textField4, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 0, 5, 15), 0, 0));

				//---- label5 ----
				label5.setText("* Local port: ");
				label5.setHorizontalAlignment(SwingConstants.RIGHT);
				panel2.add(label5, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- textField5 ----
				textField5.setPreferredSize(new Dimension(180, 28));
				panel2.add(textField5, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 15), 0, 0));

				//---- label6 ----
				label6.setText("* Our ID: ");
				label6.setHorizontalAlignment(SwingConstants.RIGHT);
				panel2.add(label6, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- textField6 ----
				textField6.setPreferredSize(new Dimension(180, 28));
				panel2.add(textField6, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 15), 0, 0));

				//---- checkBox1 ----
				checkBox1.setText("Initial Tor Portable at start");
				checkBox1.setPreferredSize(new Dimension(60, 18));
				checkBox1.setMinimumSize(new Dimension(30, 18));
				panel2.add(checkBox1, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 15), 0, 0));

				//---- checkBox9 ----
				checkBox9.setText("obfsproxy (portable only)");
				panel2.add(checkBox9, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- label3 ----
				label3.setText("Note: Our ID is your hostname without .onion");
				panel2.add(label3, new GridBagConstraints(0, 5, 2, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 10, 5, 15), 0, 0));

				//---- label7 ----
				label7.setText("* Required");
				panel2.add(label7, new GridBagConstraints(1, 6, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 15), 0, 0));
			}
			tabbedPane1.addTab("Advanced", panel2);


			//======== panel3 ========
			{
				panel3.setLayout(new GridBagLayout());
				((GridBagLayout)panel3.getLayout()).columnWidths = new int[] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
				((GridBagLayout)panel3.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0, 0, 0};
				((GridBagLayout)panel3.getLayout()).columnWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};
				((GridBagLayout)panel3.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

				//---- label8 ----
				label8.setText("URL to buddylist");
				label8.setHorizontalAlignment(SwingConstants.RIGHT);
				panel3.add(label8, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 10, 5, 5), 0, 0));

				//---- textField7 ----
				textField7.setPreferredSize(new Dimension(180, 28));
				panel3.add(textField7, new GridBagConstraints(1, 2, 7, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 0, 5, 15), 0, 0));

				//---- button2 ----
				button2.setText("sync");
				button2.setMaximumSize(new Dimension(100, 23));
				button2.setMinimumSize(new Dimension(100, 23));
				button2.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						sync(e);
					}
				});
				panel3.add(button2, new GridBagConstraints(8, 2, 3, 1, 0.0, 0.0,
					GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- checkBox3 ----
				checkBox3.setText("sync at every start");
				checkBox3.setPreferredSize(new Dimension(60, 18));
				checkBox3.setMinimumSize(new Dimension(30, 18));
				panel3.add(checkBox3, new GridBagConstraints(1, 4, 7, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 15), 0, 0));
			}
			tabbedPane1.addTab("Buddy Sync", panel3);


			//======== panel4 ========
			{
				panel4.setLayout(new GridBagLayout());
				((GridBagLayout)panel4.getLayout()).columnWidths = new int[] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
				((GridBagLayout)panel4.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0, 0, 0};
				((GridBagLayout)panel4.getLayout()).columnWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};
				((GridBagLayout)panel4.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

				//---- label9 ----
				label9.setText("URL for check");
				label9.setHorizontalAlignment(SwingConstants.RIGHT);
				panel4.add(label9, new GridBagConstraints(5, 1, 4, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 10, 5, 5), 0, 0));

				//---- textField8 ----
				textField8.setPreferredSize(new Dimension(180, 28));
				panel4.add(textField8, new GridBagConstraints(9, 1, 7, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(10, 0, 5, 15), 0, 0));

				//---- button3 ----
				button3.setText("check");
				button3.setMaximumSize(new Dimension(100, 23));
				button3.setMinimumSize(new Dimension(100, 23));
				button3.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						update(e);
					}
				});
				panel4.add(button3, new GridBagConstraints(11, 3, 1, 1, 0.0, 0.0,
					GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE,
					new Insets(0, 0, 5, 5), 0, 0));

				//---- checkBox6 ----
				checkBox6.setText("check for update at every start");
				checkBox6.setPreferredSize(new Dimension(60, 18));
				checkBox6.setMinimumSize(new Dimension(30, 18));
				panel4.add(checkBox6, new GridBagConstraints(7, 5, 10, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 15), 0, 0));
			}
			tabbedPane1.addTab("Update Check", panel4);

		}
		contentPane.add(tabbedPane1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.CENTER, GridBagConstraints.BOTH,
			new Insets(0, 0, 0, 0), 0, 0));

		//---- button1 ----
		button1.setText("Ok");
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ok(e);
			}
		});
		contentPane.add(button1, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
			new Insets(0, 0, 10, 10), 0, 0));
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - jhgfdf jhgfc
	private JTabbedPane tabbedPane1;
	private JPanel panel1;
	private JLabel label1;
	private JTextField textField1;
	private JLabel label2;
	private JTextField textField2;
	private JCheckBox checkBox2;
	private JCheckBox checkBox4;
	private JCheckBox checkBox5;
	private JCheckBox checkBox7;
	private JCheckBox checkBox8;
	private JCheckBox checkBox10;
	private JPanel panel2;
	private JLabel label4;
	private JTextField textField4;
	private JLabel label5;
	private JTextField textField5;
	private JLabel label6;
	private JTextField textField6;
	private JCheckBox checkBox1;
	private JCheckBox checkBox9;
	private JLabel label3;
	private JLabel label7;
	private JPanel panel3;
	private JLabel label8;
	private JTextField textField7;
	private JButton button2;
	private JCheckBox checkBox3;
	private JPanel panel4;
	private JLabel label9;
	private JTextField textField8;
	private JButton button3;
	private JCheckBox checkBox6;
	private JButton button1;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
