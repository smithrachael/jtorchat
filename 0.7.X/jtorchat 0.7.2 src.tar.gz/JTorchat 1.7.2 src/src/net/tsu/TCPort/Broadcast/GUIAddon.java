package net.tsu.TCPort.Broadcast;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.*;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
/*
 * Created by JFormDesigner on Tue Jan 10 16:46:18 EST 2012
 */
import net.tsu.TCPort.Config;



/**
 * @author Tsu
 */
@SuppressWarnings("serial")
public class GUIAddon extends JPanel {
	public static GUIAddon instance;

	public GUIAddon() {
		instance = this;
		initComponents();
		Broadcast.init(); // if it hasn't already
		// [FIXME]
		String[] array = Broadcast.tagMap.keySet().toArray(new String[0]);
		Arrays.sort(array);
		ArrayList<String> x = new ArrayList<String>();
		x.addAll(Arrays.asList(array));
		x.add(0, "All");
		comboBox1.setModel(new DefaultComboBoxModel(x.toArray(new String[0])));
//		textField1.setEditable(false);
		textField1.setEnabled(false);
		button1.setEnabled(false);
		// [/FIXME] this is a terrible wya to do it
	}

	private void send(ActionEvent e) {
		String text = textField1.getText();
		if (text.length() > 0) {
			Broadcast.broadcast((String) comboBox1.getSelectedItem(), Config.us, text, Broadcast.forwardAll, true);
			textField1.setText("");
		}
	}

	
	public JTextPane getTextPane2() {
		return textPane2;
	}

	private void itemChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			if (e.getItem().equals("All")) {
				button1.setEnabled(false);
				textField1.setEnabled(false);
			} else {
				textField1.setEnabled(true);
				button1.setEnabled(true);
			}

			DefaultStyledDocument d = Broadcast.minilog.get((String) e.getItem());
			if (d == null) {
				d = new DefaultStyledDocument();
				Broadcast.minilog.put((String) e.getItem(), d);
				Style timestampStyle = d.addStyle("Time Stamp", null);
			    StyleConstants.setForeground(timestampStyle, Color.gray.darker());
			    Style myNameStyle = d.addStyle("Sender", null);
			    StyleConstants.setForeground(myNameStyle, Color.blue.darker());
			    Style theirNameStyle = d.addStyle("Tag", null);
			    StyleConstants.setForeground(theirNameStyle, Color.red.darker());
			}
			textPane2.setDocument(d);
			GUIAddon.instance.getTextPane2().setCaretPosition(GUIAddon.instance.getTextPane2().getDocument().getLength());
		}
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - TIm daaa
		comboBox1 = new JComboBox();
		button1 = new JButton();
		scrollPane2 = new JScrollPane();
		textPane2 = new JTextPane();
		textField1 = new JTextField();
		label1 = new JLabel();
		button2 = new JButton();
    	comboBox2 = new JComboBox();

		//======== this ========

		// JFormDesigner evaluation mark
		setBorder(new javax.swing.border.CompoundBorder(
			new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
				"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
				javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
				java.awt.Color.red), getBorder())); addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});


		//---- comboBox1 ----
		comboBox1.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				itemChanged(e);
			}
		});

		//---- button1 ----
		button1.setText("Send");
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				send(e);
			}
		});

		//======== scrollPane2 ========
		{

			//---- textPane2 ----
			textPane2.setPreferredSize(new Dimension(300, 200));
			textPane2.setEditable(false);
			scrollPane2.setViewportView(textPane2);
		}

		//---- textField1 ----
		textField1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				send(e);
			}
		});

		//---- label1 ----
		label1.setText("Tag: ");

		//---- button2 ----
		button2.setText("Tag Settings");
		button2.setEnabled(false);

		//---- comboBox2 ----
		comboBox2.setModel(new DefaultComboBoxModel(new String[] {
			"Minilog",
			"Log",
			"Both"
		}));
		comboBox2.setEnabled(false);
		comboBox2.setPreferredSize(new Dimension(78, 26));

		GroupLayout layout = new GroupLayout(this);
		setLayout(layout);
		layout.setHorizontalGroup(
			layout.createParallelGroup()
				.addGroup(layout.createSequentialGroup()
					.addContainerGap()
					.addGroup(layout.createParallelGroup()
						.addComponent(scrollPane2, GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE)
						.addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
							.addComponent(textField1, GroupLayout.DEFAULT_SIZE, 312, Short.MAX_VALUE)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(button1))
						.addGroup(layout.createSequentialGroup()
							.addComponent(label1)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(comboBox1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 98, Short.MAX_VALUE)
							.addComponent(comboBox2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(button2)))
					.addContainerGap())
		);
		layout.setVerticalGroup(
			layout.createParallelGroup()
				.addGroup(layout.createSequentialGroup()
					.addContainerGap()
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
						.addComponent(label1)
						.addComponent(comboBox1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(button2)
						.addComponent(comboBox2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
					.addComponent(scrollPane2, GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
					.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(button1)
						.addComponent(textField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - TIm daaa
	private JComboBox comboBox1;
	private JButton button1;
	private JScrollPane scrollPane2;
	private JTextPane textPane2;
	private JTextField textField1;
	private JLabel label1;
	private JButton button2;
	private JComboBox comboBox2;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
