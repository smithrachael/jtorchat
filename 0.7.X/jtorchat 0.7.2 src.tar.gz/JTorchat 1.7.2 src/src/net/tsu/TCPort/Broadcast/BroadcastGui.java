package net.tsu.TCPort.Broadcast;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.JSeparator;

import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Config;
import net.tsu.TCPort.Gui.Gui;
import net.tsu.TCPort.Gui.GuiListener;

public class BroadcastGui {
	static Listener lis;
	static void init() { // Check for Gui class should've already been done
		if (lis != null) {
			// wth
			return;
		}
		
		Gui.getInstance().cmdListeners.put("broadcast", lis = new Listener());
		Gui.getInstance().cmdListeners.put("bcast", lis);

		JMenuItem jmiBuddyReq = new JMenuItem("Request Buddies");
		
		jmiBuddyReq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Broadcast.broadcast("$buddyRequest", Config.us, null, true, true);
			}
		});

		Gui.getInstance().getFileMenu().add(new JSeparator());
		Gui.getInstance().getFileMenu().add(jmiBuddyReq);
	}
	
	private static class Listener implements GuiListener {

		public String onCommand(Buddy buddy, String s) {
			System.out.println(s);
			if ((s.startsWith("/bcast") || s.startsWith("/broadcast")) && s.split(" ").length >= 3 && s.split(" ")[1].startsWith("#")) {
				Broadcast.broadcast(s.split(" ")[1], Config.us, s.split(" ", 3)[2], Broadcast.forwardAll, true);
			}
			return "";
		}
		
	}

}
