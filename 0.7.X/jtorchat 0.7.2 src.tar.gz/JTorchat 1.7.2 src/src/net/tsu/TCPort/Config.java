package net.tsu.TCPort;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import net.tsu.TCPort.util.Regex;


public class Config {
	public static String VERSIONA = "0";
	public static String VERSIONB = "7";
	public static String VERSIONC = "2";
	public static String comment = "test";
	public static int BUILD = Integer.parseInt(VERSIONA)*100 + Integer.parseInt(VERSIONB)*10 + Integer.parseInt(VERSIONC);
	public static String VERSION = VERSIONA+"."+VERSIONB+"."+VERSIONC+" "+comment;
	public static String BASE_DIR = "";
	public static String CONFIG_DIR = "";
	public static String DOWNLOAD_DIR = "";
	public static String LOG_DIR = "";
	public static String MESSAGE_DIR = ""; 
	public static String PAGE_DIR = ""; 
	public static int SOCKS_PORT; 
	public static int LOCAL_PORT; 
	public static int alert; 
	public static int loadTor;
	public static int visiblelog;
	public static int buddyStart;
	public static int updateStart;
	public static int updateStatus = 0;
	public static int firststart;
	public static int pageactive;
	public static int transferonstart;
	public static int allcheckupdate;
	public static String sync; 
	public static String update; 
	public static String us;
	public static String nowstart = "";
	public static String nowstartupdate = "";
	public static String LastCheck;
	public static final Properties prop;
	
	static {
//		Matcher m = Pattern.compile("/home/.*?/").matcher(new File(".").getAbsolutePath());
//		if (m.matches()) // pretty dodgy but should work
//			BASE_DIR = ".JTorchat/";

		String x = System.getProperty("java.class.path");
		for (String s : x.split(";")) // prioritize finding the jar
			if (Regex.match(".*?[/\\\\]{0,1}jtorchat.*?\\.jar", s.toLowerCase())) {
				BASE_DIR = new File(s).isDirectory() ? new File(s).getPath() : new File(s).getParent();
				break;
			}
		if (BASE_DIR == null || BASE_DIR.length() == 0)
			for (String s : x.split(";"))
				if (!Regex.match("bin(?!.)", s.toLowerCase())) { // dodgy ~
					BASE_DIR = new File(s).isDirectory() ? new File(s).getParent() : new File(s).getParent();
					break;
				} else if (!Regex.match("build(?!.)", s.toLowerCase())) { // dodgy ~
					BASE_DIR = new File(s).isDirectory() ? new File(s).getParent() : new File(s).getParent();
					break;
				}
		if (BASE_DIR == null)
			BASE_DIR = "";
		if (BASE_DIR.length() > 0) {
			if (!BASE_DIR.endsWith("/") && !BASE_DIR.endsWith("\\"))
				BASE_DIR += "/";
			Logger.log(Logger.NOTICE, "Config", "Using " + BASE_DIR + " as BASE_DIR");
		}
		
		CONFIG_DIR = Config.BASE_DIR + "data/config/";
		DOWNLOAD_DIR =  Config.BASE_DIR + "data/downloads/";
		LOG_DIR =  Config.BASE_DIR + "data/log/";
		MESSAGE_DIR =  Config.BASE_DIR + "data/offlinemsgs/";
		PAGE_DIR =  Config.BASE_DIR + "data/page/";
		
		//Create all important dir
		new File(CONFIG_DIR).mkdirs();
		new File(DOWNLOAD_DIR).mkdirs();
		new File(LOG_DIR).mkdirs();
		new File(MESSAGE_DIR).mkdirs();
		new File(PAGE_DIR).mkdirs();

		Logger.log(Logger.NOTICE, "Config", "Using " + CONFIG_DIR + " as CONFIG_DIR");
		Logger.log(Logger.NOTICE, "Config", "Using " + DOWNLOAD_DIR + " as DOWNLOAD_DIR");
		Logger.log(Logger.NOTICE, "Config", "Using " + LOG_DIR + " as LOG_DIR");
		prop = new Properties();
		try {
			prop.load(new FileInputStream(CONFIG_DIR + "settings.ini"));
		} catch (FileNotFoundException e) {
//			e.printStackTrace();
		} catch (IOException e) {
//			e.printStackTrace();
		}
		
		

			us = assign("ourId", null, prop);
	
				SOCKS_PORT = assignInt("SOCKS_PORT", 11158, prop);
				LOCAL_PORT = assignInt("LOCAL_PORT", 8976, prop);

	
		
		
		TCPort.profile_name = assign("profile_name", null, prop);
		TCPort.profile_text = assign("profile_text", null, prop);
		Config.sync = assign("sync", null, prop);
		Config.update = assign("update", null, prop);
		Config.alert = assignInt("alert", 1, prop);
		Config.loadTor = assignInt("loadPortableTor", 1, prop);
		Config.buddyStart = assignInt("OnStartBuddySync", 0, prop);
		Config.updateStart = assignInt("OnStartUpdateCheck", 0, prop);
		Config.firststart = assignInt("firststart", 0, prop);
		Config.visiblelog = assignInt("loggerEnable", 0, prop);
		Config.pageactive = assignInt("pageactive", 0, prop);
		Config.transferonstart = assignInt("transferonstart", 0, prop);
		
		if (Config.buddyStart == 1)
		{
		nowstart=sync;
		}
		
		if (Config.updateStart == 1)
		{
		nowstartupdate=update;
		}
		
		Logger.log(Logger.INFO, "Config", "Using " + SOCKS_PORT + " as socks port and " + LOCAL_PORT + " as local port.");
	}
	
	public static void reloadSettings() { // reloads almost all settings

		new File(CONFIG_DIR).mkdirs();
		prop.clear();
		try {
			prop.load(new FileInputStream(CONFIG_DIR + "settings.ini"));
		} catch (FileNotFoundException e) {
			System.err.println(e.getLocalizedMessage());
		} catch (IOException e) {
			System.err.println(e.getLocalizedMessage());
		}
		
		
			SOCKS_PORT = assignInt("SOCKS_PORT", 11158, prop);
			LOCAL_PORT = assignInt("LOCAL_PORT", 8976, prop);
			us = assign("ourId", null, prop);

		
		TCPort.profile_name = assign("profile_name", null, prop);
		TCPort.profile_text = assign("profile_text", null, prop);
		Config.sync = assign("sync", null, prop);
		Config.update = assign("update", null, prop);
		Config.alert = assignInt("alert", 1, prop);
		Config.loadTor = assignInt("loadPortableTor", 1, prop);
		Config.buddyStart = assignInt("OnStartBuddySync", 0, prop);
		Config.updateStart = assignInt("OnStartUpdateCheck", 0, prop);
		Config.firststart = assignInt("firststart", 0, prop);
		Config.visiblelog = assignInt("loggerEnable", 0, prop);
		Config.pageactive = assignInt("pageactive", 0, prop);
		Config.transferonstart = assignInt("transferonstart", 0, prop);
		
		if (Config.buddyStart == 1)
		{
		nowstart=sync;
		}
		
		if (Config.updateStart == 1)
		{
		nowstartupdate=update;
		}
		
		Logger.log(Logger.INFO, "Config", "Using " + SOCKS_PORT + " as socks port and " + LOCAL_PORT + " as local port.");
	}
	
	public static final int DEAD_CONNECTION_TIMEOUT = 240;
	public static final int KEEPALIVE_INTERVAL = (int) (Math.random()*120); //120;
	public static final int MAX_UNANSWERED_PINGS = 4;
	public static final int CONNECT_TIMEOUT = 70;
	
	public static final String CLIENT = "JTC [T2]";
	
	private static int assignInt(String string, int def, Properties prop) {
		String x = (String) prop.get(string);
		int i = def;
		if (x != null)
			try {
				i = Integer.parseInt(x);
			} catch (NumberFormatException nfe) {
				System.err.println(nfe.getLocalizedMessage());
			}
		if (i == def)
			Logger.log(Logger.NOTICE, "Config", string + " not defined using " + def);
		return i;
	}

	public static String assign(String string, String s, Properties prop) {
		String x = (String) prop.get(string);
		String ret = s;
		if (x != null)
			ret = x;
		if (ret == null && s == null || s != null && ret != null && ret.equals(s))
			Logger.log(Logger.NOTICE, "Config", string + " not defined using " + s);
		return ret;
	}
	
}
