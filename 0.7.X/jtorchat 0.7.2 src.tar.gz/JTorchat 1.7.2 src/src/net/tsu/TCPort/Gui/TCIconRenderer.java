package net.tsu.TCPort.Gui;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Logger;

@SuppressWarnings("serial")
public class TCIconRenderer extends DefaultTreeCellRenderer {
	public static final ImageIcon awayIcon;
	public static final ImageIcon handshakeIcon;
	public static final ImageIcon offlineIcon;
	public static final ImageIcon onlineIcon;
	public static final ImageIcon xaIcon;
	public static final Image awayImage;
	public static final Image handshakeImage;
	public static final Image offlineImage;
	public static final Image onlineImage;
	public static final Image xaImage;
	private JTree t;
	
	static {
		Logger.log(Logger.INFO, "Gui", "Loading status icons.");
		awayIcon = new ImageIcon(TCIconRenderer.class.getResource("/images/away.png"));
		handshakeIcon = new ImageIcon(TCIconRenderer.class.getResource("/images/connecting.png"));
		offlineIcon = new ImageIcon(TCIconRenderer.class.getResource("/images/offline.png"));
		onlineIcon = new ImageIcon(TCIconRenderer.class.getResource("/images/online.png"));
		xaIcon = new ImageIcon(TCIconRenderer.class.getResource("/images/xa.png"));
		awayImage = getImg(TCIconRenderer.class.getResource("/images/away.png"));
		handshakeImage = getImg(TCIconRenderer.class.getResource("/images/connecting.png"));
		offlineImage = getImg(TCIconRenderer.class.getResource("/images/offline.png"));
		onlineImage = getImg(TCIconRenderer.class.getResource("/images/online.png"));
		xaImage = getImg(TCIconRenderer.class.getResource("/images/xa.png"));
//		awayIcon = new ImageIcon("images/away.png");
//		handshakeIcon = new ImageIcon("images/connecting.png");
//		offlineIcon = new ImageIcon("images/offline.png");
//		onlineIcon = new ImageIcon("images/online.png");
//		xaIcon = new ImageIcon("images/xa.png");
//		awayImage = getImg("images/away.png");
//		handshakeImage = getImg("images/connecting.png");
//		offlineImage = getImg("images/offline.png");
//		onlineImage = getImg("images/online.png");
//		xaImage = getImg("images/xa.png");
		
	}
	
	public static Image getImg(URL u) {
		try {
			Image x = ImageIO.read(u);
//			System.out.println("Loaded: " + x);
			return x;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static Image getImg(String s) {
		try {
			Image x = ImageIO.read(new File(s));
//			System.out.println("Loaded: " + x);
			return x;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public TCIconRenderer(JTree t) {
		this.t = t;
	}

	public Component getTreeCellRendererComponent(JTree tree, Object value,
			boolean sel, boolean expanded, boolean leaf, int row,
			boolean hasFocus) {

		super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf,
				row, hasFocus);
		
		Object nodeObj = ((DefaultMutableTreeNode) value).getUserObject();
		if (nodeObj instanceof Buddy) {
			Buddy b = ((Buddy) nodeObj);
			int status = b.getStatus();
			String s = "<html>" + b.getAddress();
			if (b.getProfile_name() != null && !b.getProfile_name().equals(""))
				s += "<BR>" + b.getProfile_name();
			if (b.getProfile_text() != null && !b.getProfile_text().equals(""))
				s += "<BR>" + b.getProfile_text();
			if (b.getClient() != null && !b.getClient().equals(""))
				s += "<BR>" + b.getClient() + " " + b.getVersion(); 
					
			s += "</html>";
			this.setToolTipText(s);
			setIcon(getStatusIcon(status));
		}
		return this;
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension dim = super.getPreferredSize();
		FontMetrics fm = getFontMetrics(getFont());
		char[] chars = getText().toCharArray();
		Rectangle2D r = fm.getStringBounds(getText(), t.getGraphics());
//		System.out.println(this.getText());

		int w = getIconTextGap() + 16;
		for (char ch : chars) {
			w += fm.charWidth(ch);
		}
		w += getText().length();
		dim.width = w;
		// horizontal scroll disabled so its fine
		return new Dimension(1000, (int) r.getHeight());
//		return new Dimension((int) r.getWidth() + 22 + Gui.getInstance().extraSpace, (int) r.getHeight());
	}

	public static ImageIcon getStatusIcon(int status) {
		// TODO Auto-generated method stub
		if (status == Buddy.AWAY) {
			return awayIcon;
		} else if (status == Buddy.HANDSHAKE) {
			return handshakeIcon;
		} else if (status == Buddy.OFFLINE) {
			return offlineIcon;
		} else if (status == Buddy.ONLINE) {
			// System.out .println("onlie");
			return onlineIcon;
		} else if (status == Buddy.XA) {
			return xaIcon;
		}
		return null;
	}
}