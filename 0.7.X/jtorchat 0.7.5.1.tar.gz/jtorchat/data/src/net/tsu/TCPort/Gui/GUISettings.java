package net.tsu.TCPort.Gui;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.*;


import net.tsu.TCPort.Config;
import net.tsu.TCPort.TCPort;
import net.tsu.TCPort.lang;

@SuppressWarnings("serial")
public class GUISettings extends JFrame {
//	private boolean hasBroadcast = false;
	
	public GUISettings() {
//		try {
//			Class.forName("net.tsu.TCPort.Broadcast.Broadcast");
//			hasBroadcast = true;
//		} catch (ClassNotFoundException e) {
//			// ignored
//		}
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		initComponents();
		language();
		textField1.setText(TCPort.profile_name);
		textField2.setText(TCPort.profile_text);
		textField4.setText(Config.SOCKS_PORT > 0 ? Config.SOCKS_PORT + "" : "");
		textField5.setText(Config.LOCAL_PORT > 0 ? Config.LOCAL_PORT + "" : "");
		textField6.setText((Config.us != null && Config.us.length() > 0) ? Config.us : "");
		textField7.setText(Config.sync);
		textField8.setText(Config.update);
		textField9.setText(Config.lang);
		if (Config.alert == 1) { checkBox2.setSelected(true); } else { checkBox2.setSelected(false); }
		if (Config.loadTor == 1) { checkBox1.setSelected(true); } else { checkBox1.setSelected(false); }
		if (Config.buddyStart == 1) { checkBox3.setSelected(true); } else { checkBox3.setSelected(false); }
		if (Config.transferonstart == 1) { checkBox4.setSelected(true); } else { checkBox4.setSelected(false); }
		if (Config.pageactive == 1) { checkBox5.setSelected(true); } else { checkBox5.setSelected(false); }
		if (Config.updateStart == 1) { checkBox6.setSelected(true); } else { checkBox6.setSelected(false); }
		if (Config.visiblelog == 1) { checkBox7.setSelected(true); } else { checkBox7.setSelected(false); }
		if (Config.fulllog == 1) { checkBox8.setSelected(true); } else { checkBox8.setSelected(false); }
		if (Config.obfsproxy == 1) { checkBox9.setSelected(true); } else { checkBox9.setSelected(false); }
		if (Config.ClickableLinks == 1) { checkBox10.setSelected(true); } else { checkBox10.setSelected(false); }							
		
		this.addWindowListener(new WindowListener() {
            @Override
			public void windowClosed(WindowEvent e) {}
            @Override
			public void windowActivated(WindowEvent e) {}
            @Override
			public void windowClosing(WindowEvent e) {
        		dispose();
        		synchronized(this) {
        			this.notifyAll(); // tell anyone waiting on us that we're done
        		}
            }
            @Override
			public void windowDeactivated(WindowEvent e) {}
            @Override
			public void windowDeiconified(WindowEvent e) {}
            @Override
			public void windowIconified(WindowEvent e) {}
            @Override
			public void windowOpened(WindowEvent e) {}
        });
	}

	private void ok(ActionEvent e) {
		String name = textField1.getText();
		String prof = textField2.getText();
		String sync = textField7.getText();
		String update = textField8.getText();
		String lang = textField9.getText();
		boolean alert = checkBox2.isSelected();
		boolean loadTor = checkBox1.isSelected();
		boolean buddyStart = checkBox3.isSelected();
		boolean updateStart = checkBox6.isSelected();
		boolean showlog = checkBox7.isSelected();
		boolean fulllog = checkBox8.isSelected();
		boolean file = checkBox4.isSelected();
		boolean page = checkBox5.isSelected();
		boolean obfsproxy = checkBox9.isSelected();
		boolean ClickableLinks = checkBox10.isSelected();
		
		int sp = -1, lp = -1;
		
		if (textField4.getText().length() != 0) {
			try {
				sp = Integer.parseInt(textField4.getText());
				if (sp < 1) {
					JOptionPane.showMessageDialog(null, textField4.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
					return;
				}
			} catch (NumberFormatException nfe) {
				JOptionPane.showMessageDialog(null, textField4.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		if (textField5.getText().length() != 0) {
			try {
				lp = Integer.parseInt(textField5.getText());
				if (lp < 1) {
					JOptionPane.showMessageDialog(null, textField5.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
					return;
				}
			} catch (NumberFormatException nfe) {
				JOptionPane.showMessageDialog(null, textField5.getText() + " is an invalid number", "Invalid Number", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		if (textField6.getText().length() == 16) {
			Config.us = textField6.getText(); // FIXME not fully checking the id
		} else if (textField6.getText().length() != 0) {
			JOptionPane.showMessageDialog(null, textField6.getText() + " is an invalid Id", "Invalid Id", JOptionPane.ERROR_MESSAGE);
			return;
		}
		Config.SOCKS_PORT = sp;
		Config.LOCAL_PORT = lp;
		Config.lang = lang;
		Config.sync = sync;
		Config.update = update;
		if (alert) { Config.alert = 1; } else {Config.alert = 0; } ;
		if (loadTor) { Config.loadTor = 1; } else {Config.loadTor = 0; } ;
		if (buddyStart) { Config.buddyStart = 1; } else {Config.buddyStart = 0; } ;
		if (updateStart) { Config.updateStart = 1; } else {Config.updateStart = 0; } ;
		TCPort.profile_name = name;
		TCPort.profile_text = prof;
		if (file) { Config.transferonstart = 1; } else {Config.transferonstart = 0; } ;
		if (page) { Config.pageactive = 1; } else {Config.pageactive = 0; } ;
		if (showlog) { Config.visiblelog = 1; } else {Config.visiblelog = 0; } ;
		if (fulllog) { Config.fulllog = 1; } else {Config.fulllog = 0; } ;
		if (obfsproxy) { Config.obfsproxy = 1; } else {Config.obfsproxy = 0; } ;		
		if (ClickableLinks) { Config.ClickableLinks = 1; } else {Config.ClickableLinks = 0; } ;
		
		Config.prop.put("profile_name", name);
		Config.prop.put("profile_text", prof);
		Config.prop.put("SOCKS_PORT", Config.SOCKS_PORT + "");
		Config.prop.put("LOCAL_PORT", Config.LOCAL_PORT + "");
		Config.prop.put("ourId", Config.us == null ? "" : Config.us);
		Config.prop.put("sync", sync);
		Config.prop.put("update", update);
		Config.prop.put("lang", lang);
		
	    if (alert) { Config.prop.put("alert", 1 + ""); } else {Config.prop.put("alert", 0 + ""); } ;
	    if (loadTor) { Config.prop.put("loadPortableTor", 1 + ""); } else {Config.prop.put("loadTor", 0 + ""); } ;
	    if (buddyStart) { Config.prop.put("OnStartBuddySync", 1 + ""); } else {Config.prop.put("OnStartBuddySync", 0 + ""); } ;
	    if (updateStart) { Config.prop.put("OnStartUpdateCheck", 1 + ""); } else {Config.prop.put("OnStartUpdateCheck", 0 + ""); } ;
	    if (file) { Config.prop.put("transferonstart", 1 + ""); } else {Config.prop.put("transferonstart", 0 + ""); } ;
	    if (page) { Config.prop.put("pageactive", 1 + ""); } else {Config.prop.put("pageactive", 0 + ""); } ;
	    if (showlog) { Config.prop.put("OnStartLoggerDisplay", 1 + ""); } else {Config.prop.put("OnStartLoggerDisplay", 0 + ""); } ;
	    if (fulllog) { Config.prop.put("EnableFullLoggerMode", 1 + ""); } else {Config.prop.put("EnableFullLoggerMode", 0 + ""); } ;
	    if (obfsproxy) { Config.prop.put("obfsproxy", 1 + ""); } else {Config.prop.put("obfsproxy", 0 + ""); } ;
	    if (ClickableLinks) { Config.prop.put("ClickableLinks", 1 + ""); } else {Config.prop.put("ClickableLinks", 0 + ""); } ;

	    TCPort.sendMyInfo();
		try {
			Config.prop.store(new FileOutputStream(Config.CONFIG_DIR + "settings.ini"), null);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		
		dispose();
		synchronized(this) {
			this.notifyAll(); // tell anyone waiting on us that we're done
		}
	}

	public JTabbedPane getTabbedPane1() {
		return tabbedPane1;
	}

	private void update(ActionEvent e) {
		Config.nowstartupdate = textField8.getText();
		Config.allcheckupdate = 1;
	}

	private void sync(ActionEvent e) {
		Config.nowstart = textField7.getText();
	}


	private void language()
	{

		label1.setText("Profile name: ");
		label2.setText("Profile text: ");
		checkBox2.setText(lang.langtext[20]);
		checkBox4.setText(lang.langtext[21]);
		checkBox5.setText(lang.langtext[22]);
		checkBox7.setText(lang.langtext[23]);
		checkBox8.setText(lang.langtext[24]);
		checkBox10.setText("Clickable Links (open with broswer)");
		label4.setText(lang.langtext[25]);
		label5.setText(lang.langtext[26]);
		label6.setText(lang.langtext[27]);
		checkBox1.setText(lang.langtext[28]);
		checkBox9.setText(lang.langtext[38]);
		label3.setText(lang.langtext[29]);
		label7.setText(lang.langtext[30]);
		label8.setText(lang.langtext[31]);
		button2.setText(lang.langtext[33]);
		checkBox3.setText(lang.langtext[32]);
		label9.setText(lang.langtext[34]);
		button3.setText(lang.langtext[35]);
		checkBox6.setText(lang.langtext[36]);
		button4.setText("Check");
		textField10.setText("Enter your language (example: en) and restart jtorchat");
		textField13.setText("When the language file not exist, the default language is en");

	
	tabbedPane1.removeAll();
	tabbedPane1.addTab(lang.langtext[16], panel1);
	tabbedPane1.addTab(lang.langtext[17], panel2);
	tabbedPane1.addTab(lang.langtext[18], panel3);
	tabbedPane1.addTab(lang.langtext[19], panel4);
	tabbedPane1.addTab("Language", panel5);


	}

	private void button4ActionPerformed(ActionEvent e) {
		String[] info = net.tsu.TCPort.lang.getinfo(textField9.getText());
		textField3.setText(info[0]);
		textField11.setText(info[1]);
		textField12.setText(info[2]);
	}
	
	
	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - jhgfdf jhgfc
		tabbedPane1 = new JTabbedPane();
		panel1 = new JPanel();
		label1 = new JLabel();
		textField1 = new JTextField();
		label2 = new JLabel();
		textField2 = new JTextField();
		checkBox2 = new JCheckBox();
		checkBox4 = new JCheckBox();
		checkBox5 = new JCheckBox();
		checkBox7 = new JCheckBox();
		checkBox8 = new JCheckBox();
		checkBox10 = new JCheckBox();
		panel2 = new JPanel();
		label4 = new JLabel();
		textField4 = new JTextField();
		label5 = new JLabel();
		textField5 = new JTextField();
		label6 = new JLabel();
		textField6 = new JTextField();
		checkBox1 = new JCheckBox();
		checkBox9 = new JCheckBox();
		label3 = new JLabel();
		label7 = new JLabel();
		panel3 = new JPanel();
		label8 = new JLabel();
		textField7 = new JTextField();
		button2 = new JButton();
		checkBox3 = new JCheckBox();
		panel4 = new JPanel();
		label9 = new JLabel();
		textField8 = new JTextField();
		button3 = new JButton();
		checkBox6 = new JCheckBox();
		panel5 = new JPanel();
		textField3 = new JTextField();
		button4 = new JButton();
		textField9 = new JTextField();
		textField10 = new JTextField();
		textField11 = new JTextField();
		textField12 = new JTextField();
		textField13 = new JTextField();
		button1 = new JButton();

		//======== this ========
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridBagLayout());
		((GridBagLayout)contentPane.getLayout()).columnWidths = new int[] {0, 0};
		((GridBagLayout)contentPane.getLayout()).rowHeights = new int[] {0, 0, 0};
		((GridBagLayout)contentPane.getLayout()).columnWeights = new double[] {1.0, 1.0E-4};
		((GridBagLayout)contentPane.getLayout()).rowWeights = new double[] {1.0, 0.0, 1.0E-4};

		//======== tabbedPane1 ========
		{

			//======== panel1 ========
			{


				//---- label1 ----
				label1.setText("Profile name: ");
				label1.setHorizontalAlignment(SwingConstants.RIGHT);

				//---- textField1 ----
				textField1.setPreferredSize(new Dimension(180, 28));

				//---- label2 ----
				label2.setText("Profile text: ");
				label2.setHorizontalAlignment(SwingConstants.RIGHT);

				//---- textField2 ----
				textField2.setPreferredSize(new Dimension(180, 28));

				//---- checkBox2 ----
				checkBox2.setText("alert on events");
				checkBox2.setPreferredSize(new Dimension(60, 18));
				checkBox2.setMinimumSize(new Dimension(30, 18));
				checkBox2.setSelected(true);

				//---- checkBox4 ----
				checkBox4.setText("automatic File Transfer start");

				//---- checkBox5 ----
				checkBox5.setText("page function");

				//---- checkBox7 ----
				checkBox7.setText("show log on start");

				//---- checkBox8 ----
				checkBox8.setText("activate full log (fatal over time)");

				//---- checkBox10 ----
				checkBox10.setText("Clickable Links (open with broswer)");

				GroupLayout panel1Layout = new GroupLayout(panel1);
				panel1.setLayout(panel1Layout);
				panel1Layout.setHorizontalGroup(
					panel1Layout.createParallelGroup()
						.addGroup(GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
							.addGap(10, 10, 10)
							.addComponent(label1, GroupLayout.PREFERRED_SIZE, 158, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(textField1, GroupLayout.PREFERRED_SIZE, 212, GroupLayout.PREFERRED_SIZE))
						.addGroup(GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
							.addComponent(label2, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(textField2, GroupLayout.PREFERRED_SIZE, 212, GroupLayout.PREFERRED_SIZE))
						.addGroup(panel1Layout.createSequentialGroup()
							.addGap(12, 12, 12)
							.addComponent(checkBox2, GroupLayout.PREFERRED_SIZE, 320, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(60, Short.MAX_VALUE))
						.addGroup(panel1Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(checkBox4, GroupLayout.PREFERRED_SIZE, 306, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(74, Short.MAX_VALUE))
						.addGroup(panel1Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(checkBox5, GroupLayout.PREFERRED_SIZE, 306, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(74, Short.MAX_VALUE))
						.addGroup(panel1Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(checkBox7, GroupLayout.PREFERRED_SIZE, 306, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(74, Short.MAX_VALUE))
						.addGroup(panel1Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(checkBox8, GroupLayout.PREFERRED_SIZE, 306, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(74, Short.MAX_VALUE))
						.addGroup(panel1Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(checkBox10, GroupLayout.PREFERRED_SIZE, 306, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(74, Short.MAX_VALUE))
				);
				panel1Layout.setVerticalGroup(
					panel1Layout.createParallelGroup()
						.addGroup(panel1Layout.createSequentialGroup()
							.addGap(10, 10, 10)
							.addGroup(panel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(label1, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(5, 5, 5)
							.addGroup(panel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(label2, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(5, 5, 5)
							.addComponent(checkBox2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(3, 3, 3)
							.addComponent(checkBox4)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(checkBox5)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(checkBox7)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(checkBox8)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(checkBox10)
							.addGap(20, 20, 20))
				);
			}
			tabbedPane1.addTab("General", panel1);


			//======== panel2 ========
			{

				//---- label4 ----
				label4.setText("* Tor socks port: ");
				label4.setHorizontalAlignment(SwingConstants.RIGHT);

				//---- textField4 ----
				textField4.setPreferredSize(new Dimension(180, 28));

				//---- label5 ----
				label5.setText("* Local port: ");
				label5.setHorizontalAlignment(SwingConstants.RIGHT);

				//---- textField5 ----
				textField5.setPreferredSize(new Dimension(180, 28));

				//---- label6 ----
				label6.setText("* Our ID: ");
				label6.setHorizontalAlignment(SwingConstants.RIGHT);

				//---- textField6 ----
				textField6.setPreferredSize(new Dimension(180, 28));

				//---- checkBox1 ----
				checkBox1.setText("Initial Tor Portable at start");
				checkBox1.setPreferredSize(new Dimension(60, 18));
				checkBox1.setMinimumSize(new Dimension(30, 18));

				//---- checkBox9 ----
				checkBox9.setText("obfsproxy (portable only)");

				//---- label3 ----
				label3.setText("Note: Our ID is your hostname without .onion");

				//---- label7 ----
				label7.setText("* Required");

				GroupLayout panel2Layout = new GroupLayout(panel2);
				panel2.setLayout(panel2Layout);
				panel2Layout.setHorizontalGroup(
					panel2Layout.createParallelGroup()
						.addGroup(panel2Layout.createSequentialGroup()
							.addGroup(panel2Layout.createParallelGroup()
								.addGroup(panel2Layout.createSequentialGroup()
									.addGap(10, 10, 10)
									.addComponent(label4, GroupLayout.PREFERRED_SIZE, 190, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
									.addComponent(textField4, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE))
								.addGroup(GroupLayout.Alignment.TRAILING, panel2Layout.createSequentialGroup()
									.addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
										.addComponent(label5, GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)
										.addComponent(label6, GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE))
									.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
									.addGroup(panel2Layout.createParallelGroup()
										.addComponent(textField6, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
										.addComponent(textField5, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)))
								.addGroup(panel2Layout.createSequentialGroup()
									.addContainerGap()
									.addComponent(checkBox1, GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE))
								.addGroup(panel2Layout.createSequentialGroup()
									.addContainerGap()
									.addComponent(checkBox9, GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE))
								.addGroup(panel2Layout.createSequentialGroup()
									.addGap(13, 13, 13)
									.addComponent(label3, GroupLayout.DEFAULT_SIZE, 359, Short.MAX_VALUE))
								.addGroup(panel2Layout.createSequentialGroup()
									.addGap(79, 79, 79)
									.addComponent(label7, GroupLayout.PREFERRED_SIZE, 192, GroupLayout.PREFERRED_SIZE)))
							.addContainerGap())
				);
				panel2Layout.setVerticalGroup(
					panel2Layout.createParallelGroup()
						.addGroup(panel2Layout.createSequentialGroup()
							.addGap(10, 10, 10)
							.addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(label4, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField4, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
							.addGap(5, 5, 5)
							.addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(label5, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField5, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
							.addGap(5, 5, 5)
							.addGroup(panel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(label6, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField6, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
							.addGap(5, 5, 5)
							.addComponent(checkBox1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(5, 5, 5)
							.addComponent(checkBox9)
							.addGap(5, 5, 5)
							.addComponent(label3)
							.addGap(5, 5, 5)
							.addComponent(label7, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
							.addGap(30, 30, 30))
				);
			}
			tabbedPane1.addTab("Advanced", panel2);


			//======== panel3 ========
			{

				//---- label8 ----
				label8.setText("URL to buddylist");
				label8.setHorizontalAlignment(SwingConstants.RIGHT);

				//---- textField7 ----
				textField7.setPreferredSize(new Dimension(180, 28));

				//---- button2 ----
				button2.setText("sync");
				button2.setMaximumSize(new Dimension(100, 23));
				button2.setMinimumSize(new Dimension(100, 23));
				button2.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						sync(e);
					}
				});

				//---- checkBox3 ----
				checkBox3.setText("sync at every start");
				checkBox3.setPreferredSize(new Dimension(60, 18));
				checkBox3.setMinimumSize(new Dimension(30, 18));

				GroupLayout panel3Layout = new GroupLayout(panel3);
				panel3.setLayout(panel3Layout);
				panel3Layout.setHorizontalGroup(
					panel3Layout.createParallelGroup()
						.addGroup(panel3Layout.createSequentialGroup()
							.addGroup(panel3Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
								.addGroup(panel3Layout.createSequentialGroup()
									.addContainerGap()
									.addComponent(checkBox3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addGroup(panel3Layout.createSequentialGroup()
									.addGap(12, 12, 12)
									.addComponent(textField7, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addComponent(label8, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 378, GroupLayout.PREFERRED_SIZE)
								.addGroup(GroupLayout.Alignment.LEADING, panel3Layout.createSequentialGroup()
									.addGap(130, 130, 130)
									.addComponent(button2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)))
							.addContainerGap())
				);
				panel3Layout.setVerticalGroup(
					panel3Layout.createParallelGroup()
						.addGroup(panel3Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(label8)
							.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
							.addComponent(textField7, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
							.addGap(18, 18, 18)
							.addComponent(button2, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
							.addGap(44, 44, 44)
							.addComponent(checkBox3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(52, 52, 52))
				);
			}
			tabbedPane1.addTab("Buddy Sync", panel3);


			//======== panel4 ========
			{

				//---- label9 ----
				label9.setText("URL for check");
				label9.setHorizontalAlignment(SwingConstants.RIGHT);
				label9.setAlignmentY(0.0F);
				label9.setHorizontalTextPosition(SwingConstants.CENTER);

				//---- textField8 ----
				textField8.setPreferredSize(new Dimension(180, 28));

				//---- button3 ----
				button3.setText("check");
				button3.setMaximumSize(new Dimension(100, 23));
				button3.setMinimumSize(new Dimension(100, 23));
				button3.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						update(e);
					}
				});

				//---- checkBox6 ----
				checkBox6.setText("check for update at every start");
				checkBox6.setPreferredSize(new Dimension(60, 18));
				checkBox6.setMinimumSize(new Dimension(30, 18));

				GroupLayout panel4Layout = new GroupLayout(panel4);
				panel4.setLayout(panel4Layout);
				panel4Layout.setHorizontalGroup(
					panel4Layout.createParallelGroup()
						.addGroup(panel4Layout.createSequentialGroup()
							.addGroup(panel4Layout.createParallelGroup()
								.addGroup(panel4Layout.createSequentialGroup()
									.addContainerGap()
									.addComponent(checkBox6, GroupLayout.PREFERRED_SIZE, 309, GroupLayout.PREFERRED_SIZE))
								.addGroup(panel4Layout.createSequentialGroup()
									.addGap(122, 122, 122)
									.addComponent(button3, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE))
								.addGroup(panel4Layout.createSequentialGroup()
									.addContainerGap()
									.addGroup(panel4Layout.createParallelGroup()
										.addComponent(label9, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)
										.addComponent(textField8, GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE))))
							.addContainerGap())
				);
				panel4Layout.setVerticalGroup(
					panel4Layout.createParallelGroup()
						.addGroup(panel4Layout.createSequentialGroup()
							.addGap(8, 8, 8)
							.addComponent(label9, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(textField8, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
							.addGap(18, 18, 18)
							.addComponent(checkBox6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(30, 30, 30)
							.addComponent(button3, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(69, Short.MAX_VALUE))
				);
			}
			tabbedPane1.addTab("Update Check", panel4);


			//======== panel5 ========
			{

				//---- textField3 ----
				textField3.setEditable(false);

				//---- button4 ----
				button4.setText("Check");
				button4.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						button4ActionPerformed(e);
					}
				});

				//---- textField10 ----
				textField10.setText("Enter your language (example: en) and restart jtorchat");
				textField10.setEditable(false);

				//---- textField11 ----
				textField11.setEditable(false);

				//---- textField12 ----
				textField12.setEditable(false);

				//---- textField13 ----
				textField13.setText("When the language file not exist, the default language is en");
				textField13.setEditable(false);

				GroupLayout panel5Layout = new GroupLayout(panel5);
				panel5.setLayout(panel5Layout);
				panel5Layout.setHorizontalGroup(
					panel5Layout.createParallelGroup()
						.addGroup(GroupLayout.Alignment.TRAILING, panel5Layout.createSequentialGroup()
							.addGap(72, 72, 72)
							.addComponent(textField9, GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
							.addGap(129, 129, 129)
							.addComponent(button4)
							.addGap(89, 89, 89))
						.addGroup(panel5Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(textField10, GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)
							.addContainerGap())
						.addGroup(panel5Layout.createSequentialGroup()
							.addContainerGap()
							.addComponent(textField13, GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)
							.addContainerGap())
						.addGroup(panel5Layout.createSequentialGroup()
							.addGap(60, 60, 60)
							.addGroup(panel5Layout.createParallelGroup()
								.addComponent(textField12, GroupLayout.PREFERRED_SIZE, 247, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField11, GroupLayout.PREFERRED_SIZE, 247, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField3, GroupLayout.PREFERRED_SIZE, 247, GroupLayout.PREFERRED_SIZE))
							.addContainerGap(77, Short.MAX_VALUE))
				);
				panel5Layout.setVerticalGroup(
					panel5Layout.createParallelGroup()
						.addGroup(panel5Layout.createSequentialGroup()
							.addGroup(panel5Layout.createParallelGroup()
								.addGroup(panel5Layout.createSequentialGroup()
									.addContainerGap()
									.addComponent(textField10, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addGroup(panel5Layout.createSequentialGroup()
									.addGap(40, 40, 40)
									.addComponent(textField13, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
							.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
							.addGroup(panel5Layout.createParallelGroup()
								.addComponent(button4)
								.addComponent(textField9, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
							.addComponent(textField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18, 18, 18)
							.addComponent(textField11, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18, 18, 18)
							.addComponent(textField12, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				);
			}
			tabbedPane1.addTab("Language", panel5);

		}
		contentPane.add(tabbedPane1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.CENTER, GridBagConstraints.BOTH,
			new Insets(0, 0, 0, 0), 0, 0));

		//---- button1 ----
		button1.setText("Ok");
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ok(e);
			}
		});
		contentPane.add(button1, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
			new Insets(0, 0, 10, 10), 0, 0));
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - jhgfdf jhgfc
	private JTabbedPane tabbedPane1;
	private JPanel panel1;
	private JLabel label1;
	private JTextField textField1;
	private JLabel label2;
	private JTextField textField2;
	private JCheckBox checkBox2;
	private JCheckBox checkBox4;
	private JCheckBox checkBox5;
	private JCheckBox checkBox7;
	private JCheckBox checkBox8;
	private JCheckBox checkBox10;
	private JPanel panel2;
	private JLabel label4;
	private JTextField textField4;
	private JLabel label5;
	private JTextField textField5;
	private JLabel label6;
	private JTextField textField6;
	private JCheckBox checkBox1;
	private JCheckBox checkBox9;
	private JLabel label3;
	private JLabel label7;
	private JPanel panel3;
	private JLabel label8;
	private JTextField textField7;
	private JButton button2;
	private JCheckBox checkBox3;
	private JPanel panel4;
	private JLabel label9;
	private JTextField textField8;
	private JButton button3;
	private JCheckBox checkBox6;
	private JPanel panel5;
	private JTextField textField3;
	private JButton button4;
	private JTextField textField9;
	private JTextField textField10;
	private JTextField textField11;
	private JTextField textField12;
	private JTextField textField13;
	private JButton button1;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
