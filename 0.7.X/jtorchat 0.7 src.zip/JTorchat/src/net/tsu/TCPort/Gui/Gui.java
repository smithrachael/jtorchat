package net.tsu.TCPort.Gui;

import java.awt.BorderLayout;
import java.awt.SystemTray;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;

import net.tsu.TCPort.APIManager;
import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Config;
import net.tsu.TCPort.Logger;
import net.tsu.TCPort.TCPort;
import net.tsu.TCPort.listeners.APIListener;

public class Gui {

	private Listener listener;
	private JFrame f;
	private DefaultMutableTreeNode root;
	private DefaultMutableTreeNode buddyNode;
	private HashMap<String, MutableTreeNode> nodeMap = new HashMap<String, MutableTreeNode>();
	private HashMap<String, ChatWindow> windowMap = new HashMap<String, ChatWindow>();
	private JTree jt;
	private Alert alert;
	public static Gui instance;
	public HashMap<String, GuiListener> cmdListeners = new HashMap<String, GuiListener>();
	public int extraSpace;

	public void init() {
		int w = 268, h = -1;
		if (listener != null) {
			Logger.log(Logger.WARNING, this.getClass(), "init(V)V called twice?");
			return;
		}
		instance = this;
		setLAF("Nimbus");

		if ((TCPort.profile_name == null && TCPort.profile_text == null) || Config.firststart == 1) {
			Logger.log(Logger.WARNING, this.getClass(), "Start setting window");		
			Config.prop.put("firststart", "0");
			
			GUISettings guis = new GUISettings();
	    	guis.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			guis.setVisible(true);
			try {
				synchronized (guis) {
					guis.wait();
				}
			} catch (InterruptedException e) {
				// ignored
			}
		} else if (Config.SOCKS_PORT < 1 || Config.LOCAL_PORT < 1 || Config.us == null) {
			Logger.log(Logger.WARNING, this.getClass(), "Start setting window on advanced");	
   	GUISettings guis = new GUISettings();
		 guis.getTabbedPane1().setSelectedIndex(1);
			guis.setVisible(true);
			try {
				synchronized (guis) {
					guis.wait();
				}
			} catch (InterruptedException e) {
				// ignored
			}
		}


		/**
		 * extraSpace notes. 0 - should be fine for metal LAF 4 - should be fine for Nimbus
		 * 
		 * TODO - really should find a proper fix for this.
		 */
		extraSpace = 4;
		listener = new Listener();
		APIManager.addEventListener(listener);
		f = new JFrame(Config.us + " - Buddy List");
		f.setLayout(new BorderLayout());
		f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

		if (SystemTray.isSupported())
			Tray.init();
		else
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JMenuBar jmb = new JMenuBar();
		JMenu jmStatus = new JMenu("Status");
		JMenu jmHelp = new JMenu("Help");
		final JMenuItem jmiHelpLink = new JMenuItem("Wiki Link");
		jmiHelpLink.addActionListener(new ActionListener() { // note - the link is copiable so as to not open the link in the users normal browser automatically which could tip off anyone sniffing the network that they are using jtorcat

					public void actionPerformed(ActionEvent e) {
						JTextField jtf = new JTextField();
						jtf.setEditable(false);
						jtf.setText("http://code.google.com/p/jtorchat/w/list");
						JOptionPane.showMessageDialog(null, jtf, "Wiki link", JOptionPane.PLAIN_MESSAGE);					
					}
				});
		jmHelp.add(jmiHelpLink);
		
		JMenuItem jmiLog = new JMenuItem("Log");
		jmiLog.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Log.instance.setVisible(!Log.instance.isVisible());
			}
		});
		jmHelp.add(jmiLog);
		
		
		final JMenuItem jmion = new JMenuItem("Online");
		jmion.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Config.updateStatus = 1;	
			}
		});
		jmStatus.add(jmion);
		
	
		
		final JMenuItem jmiaway = new JMenuItem("Away");
		jmiaway.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Config.updateStatus = 2;
			}
		});
		jmStatus.add(jmiaway);
		
		final JMenuItem jmixa = new JMenuItem("Far Away");
		jmixa.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Config.updateStatus = 3;
			}
		});
		jmStatus.add(jmixa);

		

		


		JMenu jmFile = new JMenu("File");

		JMenuItem jmiAddContact = new JMenuItem("Add Contact");
		JMenuItem jmiSettings = new JMenuItem("Settings");
		JMenuItem jmiExit = new JMenuItem("Exit");

		jmiAddContact.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				GUIContactAdd guica = new GUIContactAdd();
				// guica.setBuddy(null); // for when editing a buddy
				guica.setVisible(true);
			}
		});
		jmiSettings.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				// JOptionPane.showMessageDialog(null, "Not Implemented", "Not Implemented", JOptionPane.ERROR_MESSAGE);
				GUISettings guis = new GUISettings();
				guis.setVisible(true);
			}
		});
		jmiExit.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		jmFile.add(jmiAddContact);
		jmFile.add(jmiSettings);
		jmFile.add(new JSeparator());
		jmFile.add(jmiExit);
		jmb.add(jmFile);
		jmb.add(jmStatus);
		jmb.add(jmHelp);

		f.setJMenuBar(jmb);

		JScrollPane jsp = new JScrollPane();
		jsp.setHorizontalScrollBar(null); // no horizontal scrollbar
		jt = new JTree();
		jsp.getViewport().add(jt);
		f.getContentPane().add(jsp, BorderLayout.CENTER);

		try {
			JPanel newInstance = (JPanel) Class.forName("net.tsu.TCPort.Broadcast.GUIAddon").getConstructor().newInstance();
			f.getContentPane().add(newInstance, BorderLayout.EAST);
			w = 665;
			// h = 478;
		} catch (Exception e) {
			// ignored
		}
		

		root = new DefaultMutableTreeNode("[root]");
		buddyNode = new DefaultMutableTreeNode("Buddies");
		root.add(buddyNode);
		jt.setModel(new DefaultTreeModel(root));
		jt.setLargeModel(true);
		jt.setRootVisible(false);
		jt.setCellRenderer(new TCIconRenderer(jt));

		jt.setRowHeight(0);
		ToolTipManager.sharedInstance().registerComponent(jt);

		jt.addMouseListener(new MouseListener() {

			public void mouseClicked(MouseEvent e) {
			}

			public void mousePressed(MouseEvent e) {
				int selRow = jt.getRowForLocation(e.getX(), e.getY());
				TreePath selPath = jt.getPathForLocation(e.getX(), e.getY());
				if (selRow != -1) {
					if (e.getClickCount() == 2 && !e.isPopupTrigger()) {
						doAction(selPath);
						// myDoubleClick(selRow, selPath);
					}
				}
				// if (e.isPopupTrigger()) // not fired here
				// doPopup(e);
			}

			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger())
					doPopup(e);
			}

			public void mouseEntered(MouseEvent e) {
			}

			public void mouseExited(MouseEvent e) {
			}

		});

		f.pack();
		if (h == -1)
			h = f.getHeight();
		f.setSize(w, h);
		f.setVisible(true);
	}

	
	public void setVisible(boolean b) {
		f.setVisible(b);
	}

	public boolean isVisible() {
		return f.isVisible();
	}

	public static void setLAF(String string) {
		try {
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if (string.equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (UnsupportedLookAndFeelException e) {
			// handle exception
		} catch (ClassNotFoundException e) {
			// handle exception
		} catch (InstantiationException e) {
			// handle exception
		} catch (IllegalAccessException e) {
			// handle exception
		}
	}

	// private void setLAF() {
	// try {
	// UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	// } catch (ClassNotFoundException e1) {
	// e1.printStackTrace();
	// } catch (InstantiationException e1) {
	// e1.printStackTrace();
	// } catch (IllegalAccessException e1) {
	// e1.printStackTrace();
	// } catch (UnsupportedLookAndFeelException e1) {
	// e1.printStackTrace();
	// }
	// }

	private JMenuItem getMenuItem(String s, ActionListener al) {
		JMenuItem menuItem = new JMenuItem(s);
		menuItem.setActionCommand(s.toUpperCase());
		menuItem.addActionListener(al);
		return menuItem;
	}

	protected void doPopup(MouseEvent e) {
		final int x = e.getX();
		final int y = e.getY();
		JTree tree = (JTree) e.getSource();
		TreePath path = tree.getPathForLocation(x, y);
		if (path == null)
			return;

		tree.setSelectionPath(path);
		JPopupMenu popup = new JPopupMenu();
		DefaultMutableTreeNode d = (DefaultMutableTreeNode) path.getLastPathComponent();
		final Object o = d.getUserObject();
		if (o instanceof Buddy) {
			popup.add(getMenuItem("Open chat.", new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					// String ac = e.getActionCommand();
					// TreePath path = jt.getPathForLocation(x, y);
					openChatWindow((Buddy) o);
				}
			}));
			popup.add(new JPopupMenu.Separator());
			popup.add(getMenuItem("Edit contact.", new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					GUIContactAdd guica = new GUIContactAdd();
					guica.setBuddy((Buddy) o); // for when editing a buddy
					guica.setVisible(true);
				}
			}));
			popup.add(getMenuItem("Delete contact.", new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					try {
						((Buddy) o).remove();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}));
			// popup.add(getMenuItem("Edit groups", al));
			popup.add(new JPopupMenu.Separator());
		}

	
		popup.show(tree, x, y);
	}

	public static Gui getInstance() {
		return instance;
	}

	private void doAction(TreePath x) {
		DefaultMutableTreeNode o = (DefaultMutableTreeNode) x.getLastPathComponent();
		if (o.getUserObject() instanceof Buddy) {
			Buddy b = (Buddy) o.getUserObject();
			openChatWindow(b);
		}
	}

	private void openChatWindow(Buddy b) {
		getChatWindow(b, true, true).toFront();
	}

	private ChatWindow getChatWindow(Buddy b, boolean createIfNotExist, boolean setVis) {
		ChatWindow w = windowMap.get(b.getAddress());
		if (w == null && !createIfNotExist)
			return null;
		if (w == null) {
			w = new ChatWindow(b);
			windowMap.put(b.getAddress(), w);
		}
		w.setIconImage(b.getStatus() == Buddy.OFFLINE ? TCIconRenderer.offlineImage : b.getStatus() == Buddy.HANDSHAKE ? TCIconRenderer.handshakeImage : b.getStatus() == Buddy.ONLINE ? TCIconRenderer.onlineImage : b.getStatus() == Buddy.AWAY ? TCIconRenderer.awayImage
				: b.getStatus() == Buddy.XA ? TCIconRenderer.xaImage : null);
		w.setTitle(b.toString(true));

		w.setFocusableWindowState(false);
		if (setVis)
			w.setVisible(true);
		w.setFocusableWindowState(true);
		return w;
	}

	private class Listener implements APIListener {

		public void onStatusChange(Buddy buddy, byte newStatus, byte oldStatus) {
			for (int i = 0; i < 3; i++)
				// repaint 3 times since sometimes it fails? FIXME
				jt.repaint();
			try {
				if (getChatWindow(buddy, false, false) != null)
					getChatWindow(buddy, false, false).setIconImage(
							newStatus == Buddy.OFFLINE ? TCIconRenderer.offlineImage : newStatus == Buddy.HANDSHAKE ? TCIconRenderer.handshakeImage : newStatus == Buddy.ONLINE ? TCIconRenderer.onlineImage : newStatus == Buddy.AWAY ? TCIconRenderer.awayImage
									: newStatus == Buddy.XA ? TCIconRenderer.xaImage : null);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (newStatus >= Buddy.ONLINE && oldStatus <= Buddy.HANDSHAKE) {
				if (new File(Config.MESSAGE_DIR + buddy.getAddress() + ".txt").exists()) {
					try {
						Scanner sc = new Scanner(new FileInputStream(Config.MESSAGE_DIR + buddy.getAddress() + ".txt"));
						while (sc.hasNextLine()) {
							try {
								buddy.sendMessage(sc.nextLine());
							} catch (IOException ioe) {
								buddy.disconnect();
								break;
							}
						}
						sc.close();
						new File(Config.MESSAGE_DIR + buddy.getAddress() + ".txt").delete();
						getChatWindow(buddy, true, true).append("Time Stamp", "Delayed messages sent.\n");
					} catch (IOException ioe) {
						ioe.printStackTrace();
					}
				}
			}
		}

		public void onProfileNameChange(Buddy buddy, String newName, String oldName) {
			jt.repaint();
			jt.setCellRenderer(null); // this is stupid, but it works
			jt.setCellRenderer(new TCIconRenderer(jt));
		}

		public void onProfileTextChange(Buddy buddy, String newText, String oldText) {

		}

		public void onAddMe(Buddy buddy) {
			jt.repaint();
		}

		public void onMessage(Buddy buddy, String s) {
			ChatWindow w = getChatWindow(buddy, true, true);

			String msg = s.trim().replaceAll("\n", "\\\\n").replaceAll("\n", "\\\\n").replaceAll("\r", "");
			
			if (msg.startsWith("/")) {
				if (msg.trim().endsWith("\\\\n")) {
					msg.substring(0, msg.length() - 6);
				}
                String command = Commands.runin(buddy, msg);
				if(command.startsWith("0"))
				{
				w.append("Me", "Private: ");
				w.append("Them",  command.substring(1).replaceAll("\\\\n", "\n").trim() + "\n");
				w.getTextPane1().setCaretPosition(w.getTextPane1().getDocument().getLength());
				w.getTextArea4().requestFocusInWindow();

				}
				else if(command.startsWith("1"))
				{
					w.append("Time Stamp", "(" + ChatWindow.getTime() + ") ");
					w.append("Them", "* " + buddy.toStringforme()+ " " + command.substring(1).replaceAll("\\\\n", "\n").trim() + "\n");
					w.getTextPane1().setCaretPosition(w.getTextPane1().getDocument().getLength());
					w.getTextArea4().requestFocusInWindow();
					
					if (!w.isFocused()) {
						if (alert != null && !alert.isFinished())
							alert.kill();
						alert = new Alert("* " + buddy.toStringforme()+ " " + command.substring(1).replaceAll("\\\\n", "\n").trim() + "\n");
						alert.start();
					}
				}
				else if(command.startsWith("2"))
				{
					w.append("Time Stamp", "(" + ChatWindow.getTime() + ") ");
					w.append("Them", " --> " + command.substring(1).replaceAll("\\\\n", "\n").trim() + "\n");
					w.getTextPane1().setCaretPosition(w.getTextPane1().getDocument().getLength());
					w.getTextArea4().requestFocusInWindow();
					
					if (!w.isFocused()) {
						if (alert != null && !alert.isFinished())
							alert.kill();
						alert = new Alert(buddy.toStringforme() + " --> " + command.substring(1).replaceAll("\\\\n", "\n").trim() + "\n");
						alert.start();
					}
				}
				else if(command.startsWith("3"))
				{
					w.append("Time Stamp", "(" + ChatWindow.getTime() + ") ");
					w.append("Me", " --> " + command.substring(1).replaceAll("\\\\n", "\n").trim() + "\n");
					w.getTextPane1().setCaretPosition(w.getTextPane1().getDocument().getLength());
					w.getTextArea4().requestFocusInWindow();
				}

			
			}
			else
			{
				
				if (!w.isFocused()) {
					if (alert != null && !alert.isFinished())
						alert.kill();
					alert = new Alert(buddy.toString() + ": " + s);
					alert.start();
				}	
				
			w.append("Time Stamp", "(" + ChatWindow.getTime() + ") ");
			w.append("Them", buddy.toString() + ": ");
			w.append("Plain", s.replaceAll("\\\\n", "\n").trim() + "\n");
			// w.getTextArea3().insert("(" + ChatWindow.getTime() + ") " + buddy.toString() + ": " + s + "\n", w.getTextArea3().getText().length());
			w.getTextPane1().setCaretPosition(w.getTextPane1().getDocument().getLength());
			w.getTextArea4().requestFocusInWindow();
			}
		}

		public void onBuddyRemoved(Buddy buddy) {
			MutableTreeNode node = nodeMap.remove(buddy.getAddress());
			if (node != null) // remove entry in the gui
				((DefaultTreeModel) jt.getModel()).removeNodeFromParent(node);
			if (getChatWindow(buddy, false, false) != null) {
				windowMap.remove(buddy.getAddress()).dispose();
			}
		}

		public void onNewBuddy(Buddy buddy) {
			MutableTreeNode node = nodeMap.get(buddy.getAddress());
			if (node != null)
				node.removeFromParent();
			nodeMap.put(buddy.getAddress(), node = new DefaultMutableTreeNode(buddy));
			((DefaultTreeModel) jt.getModel()).insertNodeInto(node, buddyNode, buddyNode.getChildCount());
			if (buddyNode.getChildCount() == 1) {
				jt.expandRow(0);
			}
		}
	}

	public JMenu getFileMenu() {
		return f.getJMenuBar().getMenu(0);
	}

}
