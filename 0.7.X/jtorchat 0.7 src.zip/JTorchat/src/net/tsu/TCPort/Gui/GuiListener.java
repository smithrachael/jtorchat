package net.tsu.TCPort.Gui;

import net.tsu.TCPort.Buddy;

public interface GuiListener {
	public String onCommand(Buddy buddy, String s);
}
