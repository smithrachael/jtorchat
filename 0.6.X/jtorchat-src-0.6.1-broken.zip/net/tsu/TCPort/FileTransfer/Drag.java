package net.tsu.TCPort.FileTransfer;

import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.io.File;
import java.util.List;

import javax.swing.JTextPane;

import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Logger;
import net.tsu.TCPort.Gui.ChatWindow;

public class Drag implements DropTargetListener {

	@Override
	public void dragEnter(DropTargetDragEvent dtde) {}

	@Override
	public void dragOver(DropTargetDragEvent dtde) {
		dtde.acceptDrag(DnDConstants.ACTION_MOVE);
	}

	@Override
	public void dropActionChanged(DropTargetDragEvent dtde) {}

	@Override
	public void dragExit(DropTargetEvent dte) {}

	@Override
	public void drop(DropTargetDropEvent dtde) {
		if ((dtde.getDropAction() & DnDConstants.ACTION_COPY_OR_MOVE) != 0) {
			dtde.acceptDrop(dtde.getDropAction());
			try {
				Buddy b = ((ChatWindow)((JTextPane) ((DropTarget) dtde.getSource()).getComponent()).getRootPane().getParent()).getBuddy();
				for (Object i : ((List<?>) dtde.getTransferable().getTransferData(DataFlavor.javaFileListFlavor))) {
					new FileSender(b, ((File)i).getAbsolutePath());
				}
//				File f = (File) ((List<?>) dtde.getTransferable().getTransferData(DataFlavor.javaFileListFlavor)).get(0);
//				new FileSender(b, f.getAbsolutePath());
				dtde.dropComplete(true);
			} catch (Exception e) {
				e.printStackTrace();
				dtde.dropComplete(false);
			}
		} else
			dtde.rejectDrop();
	}
}
