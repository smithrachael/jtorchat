package net.tsu.TCPort.FileTransfer;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;

import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Config;
import net.tsu.TCPort.Logger;

@SuppressWarnings("serial")
public class GUITransfer extends JFrame {

	private Buddy buddy;
	private boolean sending;
	private String fileName;
	private boolean completed;
	private IFileTransfer ift;

	public GUITransfer(IFileTransfer ift, Buddy b, String fileName, boolean sending) {
		this.ift = ift;
		this.buddy = b;
		this.fileName = fileName;
		this.sending = sending;
		initComponents();
		label1.setText("<html><br><br>");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		if (sending)
			getContentPane().remove(button2);
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
            	if (GUITransfer.this.ift != null)
            		GUITransfer.this.ift.close();
            }
        });
		setSize(getWidth() + 5, getHeight() + 5);
	}

	public void update(long fileSize, long recieved, String status) {
		if (recieved == -1) {
			button1.setText("Close");
			button2.setVisible(false);
		}
		double perc = Math.round(((double) recieved / (double) fileSize) * 1000) / 10d;
		label1.setText("<html>" + (sending ? "Sending " : "Recieving ") + fileName + "<br>" + (sending ? "to " : "from ") + buddy.toString(true) + "<br>" + perc + "% (" + recieved + " of " + fileSize + " bytes)    " + status);
		setTitle(perc + "% - " + fileName);
		progressBar1.setValue((int) ((double) recieved / (double) fileSize * 100d));
		Logger.oldOut.println(getClass().getCanonicalName() + ": gui() " + fileSize + ", " + recieved + ", " + status);
		if (fileSize == recieved) {
			if (sending)
				button1.setText("Close");
			completed = true;
			if (!sending && ((FileReceiver) ift).fileNameSave != null && ((FileReceiver) ift).fileNameSave.length() > 0) {
				((FileReceiver) ift).closeSave();
				button1.setText("Close");
				button2.setVisible(false);
			}
		}
	}

	public void update(long fileSize, long recieved) {
		update(fileSize, recieved, "");
		// Logger.oldOut.println(getClass().getCanonicalName() + ": gui() " + fileSize + ", " + recieved);
	}

	private void saveAs(ActionEvent e) {
		JFileChooser chooser = new JFileChooser();
		// Note: source for ExampleFileFilter can be found in FileChooserDemo,
		// under the demo/jfc directory in the Java 2 SDK, Standard Edition.
		File base = new File(Config.BASE_DIR + "downloads/");
		base.mkdirs();
		chooser.setSelectedFile(new File(base, fileName));
		chooser.setCurrentDirectory(base);
		int returnVal = chooser.showSaveDialog(this);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			((FileReceiver) ift).fileNameSave = chooser.getSelectedFile().getAbsolutePath();
			if (completed) {
				((FileReceiver) ift).closeSave();
				button1.setText("Close");
				button2.setVisible(false);
			}
		}
	}

	private void cancel(ActionEvent e) {
		if (completed) {
			if (!sending)
				ift.close();
			dispose();
			return;
		}
		ift.close();
		dispose();
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY //GEN-BEGIN:initComponents
		label1 = new JLabel();
		progressBar1 = new JProgressBar();
		button2 = new JButton();
		button1 = new JButton();

		// ======== this ========
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridBagLayout());
		((GridBagLayout) contentPane.getLayout()).columnWidths = new int[] { 0, 0, 0, 0 };
		((GridBagLayout) contentPane.getLayout()).rowHeights = new int[] { 0, 0, 0, 0 };
		((GridBagLayout) contentPane.getLayout()).columnWeights = new double[] { 0.0, 0.0, 0.0, 1.0E-4 };
		((GridBagLayout) contentPane.getLayout()).rowWeights = new double[] { 0.0, 0.0, 0.0, 1.0E-4 };

		// ---- label1 ----
		label1.setText("<html><br><br>wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
		contentPane.add(label1, new GridBagConstraints(0, 0, 3, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(10, 10, 5, 0), 0, 0));
		contentPane.add(progressBar1, new GridBagConstraints(0, 1, 3, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 10, 5, 10), 0, 0));

		// ---- button2 ----
		button2.setText("Save As");
		button2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				saveAs(e);
			}
		});
		contentPane.add(button2, new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0, GridBagConstraints.NORTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 5), 0, 0));

		// ---- button1 ----
		button1.setText("Cancel");
		button1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cancel(e);
			}
		});
		contentPane.add(button1, new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 10, 10), 0, 0));
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY //GEN-BEGIN:variables
	private JLabel label1;
	private JProgressBar progressBar1;
	private JButton button2;
	private JButton button1;
	// JFormDesigner - End of variables declaration //GEN-END:variables
}
