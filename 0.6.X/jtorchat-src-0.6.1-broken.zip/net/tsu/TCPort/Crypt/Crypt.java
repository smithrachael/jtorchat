package net.tsu.TCPort.Crypt;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyPair;

import net.tsu.TCPort.APIManager;
import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.BuddyList;
import net.tsu.TCPort.Config;
import net.tsu.TCPort.Logger;
import net.tsu.TCPort.listeners.APIListener;
import net.tsu.TCPort.listeners.CommandListener;

public class Crypt {

	private static File keyPairFile;
	private static KeyPair keyPair;
	private static Listener lis;

	public static void init() {
		if (Config.us == null)
			throw new RuntimeException("Config.us == null");
		keyPairFile = new File(Config.CONFIG_DIR + "keys/" + Config.us + ".priv");
		try {
			if (!keyPairFile.exists()) {
				keyPair = RSAHelper.generateKeyPair();
				new File(Config.CONFIG_DIR + "keys/").mkdirs();
				RSAHelper.writeKeyPair(keyPair, Config.CONFIG_DIR + "keys/" + Config.us);
			} else
				keyPair = RSAHelper.readKeyPair(Config.CONFIG_DIR + "keys/" + Config.us);
		} catch (GeneralSecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		APIManager.addEventListener(lis = new Listener());
//		APIManager.cmdListeners.put("TODO", lis);
	}

	private static class Listener implements APIListener, CommandListener {

		public void onCommand(Buddy b, String command, InputStream is) {

		}

		public void onStatusChange(Buddy buddy, byte newStatus, byte oldStatus) { // TODO this probably could/should be done better
			if (oldStatus <= Buddy.HANDSHAKE && newStatus >= Buddy.ONLINE) {// && !new File(Config.CONFIG_DIR + "keys/" + buddy.getAddress() + ".pub").exists()) {
//				try {
//					buddy.sendRaw("crypt pubkeydist " + myTags.replace("\n", ""));
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
			}
		}

		public void onProfileNameChange(Buddy buddy, String newName, String oldName) {
		}

		public void onProfileTextChange(Buddy buddy, String newText, String oldText) {
		}

		public void onAddMe(Buddy buddy) {
		}

		public void onMessage(Buddy buddy, String s) {
		}

		public void onNewBuddy(Buddy buddy) {
		}

		public void onBuddyRemoved(Buddy buddy) {
		}
	}
}
