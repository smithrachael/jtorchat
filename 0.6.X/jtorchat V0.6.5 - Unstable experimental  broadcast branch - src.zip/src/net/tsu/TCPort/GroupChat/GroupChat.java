package net.tsu.TCPort.GroupChat;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyPair;
import java.util.HashMap;
import java.util.List;

import net.tsu.TCPort.APIManager;
import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Crypt.RSAHelper;
import net.tsu.TCPort.listeners.CommandListener;
import net.tsu.TCPort.util.Util;

public class GroupChat {

	private static HashMap<String, Group> groups = new HashMap<String, Group>();
	private static Listener lis;

	public static void init() {
		if (lis != null)
			return;
		APIManager.cmdListeners.put("groupmessage", lis = new Listener());
		// APIManager.cmdListeners.put("groupmessage", lis);
	}

	private static class Group {

		private String id;
		private List<String> _part;
		private HashMap<String, Key> participants = new HashMap<String, Key>();
		private KeyPair kp; // my key

		private Group(String id) throws GeneralSecurityException {
			this.id = id;
			kp = RSAHelper.generateKeyPair();
			// Collections.sort(participants);
		}

		public void addParticipant(String address) {

		}

		public void getMessage(String sender, String content) {

		}

	}

	private static class Listener implements CommandListener {

		public void onCommand(Buddy buddy, String command, InputStream is) throws IOException {
			// groupmessage id sender content
			if (command.startsWith("groupmessage ")) {
				String id = Util.readStringTillChar(is, ' ');
				String sender = Util.readStringTillChar(is, ' '); // not trusted
				String content = Util.readStringTillChar(is, '\n');
				groups.get(id).getMessage(sender, content);
			}
		}
	}
}
