package net.tsu.TCPort.testbed;

import java.util.Arrays;

import net.tsu.TCPort.util.Util;

public class gah {

	public static void main(String[] args) throws Exception {
		System.out.println("Init.");
		byte[] b1 = new byte[] { 'h', 'e', 'l', 'l', 'o', '\n', '\n', '\n', '\\', '\n', '\n', '\n', 'w', 'o', 'r', 'l', 'd' };
		// b1 = Arrays.copyOf(b1, 8196);
		{
			b1 = Util.escape(b1);
		}
		System.out.println(asString(b1));
		{
			b1 = Util.unescape(b1);
		}
		System.out.println(asString(b1));
	}

	private static String asString(byte[] a) {
		String ret = "[";
		for (byte b : a)
			if (ret.length() == 1)
				ret += (char) b;
			else
				ret += ", " + (char) b;
		return ret + "]";
	}
}
