package net.tsu.TCPort.Crypt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

public class RSAHelper {

	private static final int keySize = 2024;

	public static KeyPair generateKeyPair() throws GeneralSecurityException {
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA", "SunRsaSign");
		kpg.initialize(keySize);
		KeyPair kp = kpg.generateKeyPair();
//		System.out.println(kp.getPrivate());
//		System.out.println(kp.getPublic());
		return kp;
	}

	public void updateFlushEveryRead(InputStream is, OutputStream os, int bufSize, Key key, int mode) {
		try {
			Cipher cipher = Cipher.getInstance("RSA", "SunJCE");
			cipher.init(mode, key);
			byte[] buf = new byte[bufSize];
			int bytesRead = 0;
			while ((bytesRead = is.read(buf)) > 0) {
				os.write(cipher.doFinal(buf, 0, bytesRead));
			}
			os.flush();
		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (GeneralSecurityException e) {
			throw new RuntimeException(e);
		}
	}

	public int getKeySize() {
		return keySize;
	}

	public static void writeKey(Key key, OutputStream os) throws IOException {
		os.write(key.getEncoded());
		os.flush();
	}

	public static void writeKeyPair(KeyPair kp, String s) throws IOException {
		writeKey(kp.getPrivate(), new FileOutputStream(s + ".priv"));
		writeKey(kp.getPublic(), new FileOutputStream(s + ".pub"));
	}

	public static KeyPair readKeyPair(String s) throws GeneralSecurityException, IOException {
		return new KeyPair(readPublicKey(s + ".pub"), readPrivateKey(s + ".priv"));
	}

	public static PrivateKey readPrivateKey(String s) throws GeneralSecurityException, IOException {
		byte[] buf = new byte[(int) new File(s).length()];
		new FileInputStream(s).read(buf);
		return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(buf));
	}

	public static PublicKey getPublicKey(byte[] b) throws GeneralSecurityException {
		return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(b));
	}

	public static PublicKey readPublicKey(String s) throws GeneralSecurityException, IOException {
		byte[] buf = new byte[(int) new File(s).length()];
		new FileInputStream(s).read(buf);
		return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(buf));
	}

	public static byte[] sign(InputStream is, PrivateKey key) throws GeneralSecurityException, IOException {
		Signature s = Signature.getInstance("SHA512WITHRSA", "SunRsaSign");
		s.initSign(key);
		byte[] buf = new byte[4096];
		int bytesRead = 0;
		while ((bytesRead = is.read(buf)) > 0)
			s.update(buf, 0, bytesRead);
		return s.sign();
	}

	public static byte[] sign(byte[] bytes, PrivateKey key) throws GeneralSecurityException, IOException {
		Signature s = Signature.getInstance("SHA512WITHRSA", "SunRsaSign");
		s.initSign(key);
		s.update(bytes);
		return s.sign();
	}

	public static boolean verify(InputStream is, byte[] sig, PublicKey key) throws GeneralSecurityException, IOException {
		Signature s = Signature.getInstance("SHA512WITHRSA", "SunRsaSign");
		s.initVerify(key);
		byte[] buf = new byte[4096];
		int bytesRead = 0;
		while ((bytesRead = is.read(buf)) > 0)
			s.update(buf, 0, bytesRead);
		return s.verify(sig);
	}

	public static boolean verify(byte[] data, byte[] sig, PublicKey key) throws GeneralSecurityException, IOException {
		Signature s = Signature.getInstance("SHA512WITHRSA", "SunRsaSign");
		s.initVerify(key);
		s.update(data);
		return s.verify(sig);
	}
}
