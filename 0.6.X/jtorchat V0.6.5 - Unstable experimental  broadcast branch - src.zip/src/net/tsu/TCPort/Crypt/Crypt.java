package net.tsu.TCPort.Crypt;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.HashMap;

import net.tsu.TCPort.APIManager;
import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Config;
import net.tsu.TCPort.Logger;
import net.tsu.TCPort.listeners.APIListener;
import net.tsu.TCPort.listeners.CommandListener;
import net.tsu.TCPort.util.Util;
import net.tsu.TCPort.util.Util.VerificationState;

public class Crypt {

	private static File keyPairFile;
	private static KeyPair keyPair;
	private static Listener lis;
	private static HashMap<String, PublicKey> keys = new HashMap<String, PublicKey>();

	public static PrivateKey getMyPrivKey() {
		return keyPair.getPrivate();
	}

	public static void init() {
		if (Config.us == null)
			throw new RuntimeException("Config.us == null");
		keyPairFile = new File(Config.CONFIG_DIR + "keys/" + Config.us + ".priv");
		keyPairFile.getParentFile().mkdirs();
		try {
			if (!keyPairFile.exists()) {
				keyPair = RSAHelper.generateKeyPair();
				RSAHelper.writeKeyPair(keyPair, Config.CONFIG_DIR + "keys/" + Config.us); // using the same name format as other buddies keys are stored so if ourId is changed then we dont use the same keys
			} else
				keyPair = RSAHelper.readKeyPair(Config.CONFIG_DIR + "keys/" + Config.us);
		} catch (GeneralSecurityException e) {
			Logger.oldOut.println(e.getLocalizedMessage());
			e.printStackTrace();
		} catch (IOException e) {
			Logger.oldOut.println(e.getLocalizedMessage());
			e.printStackTrace();
		}

		APIManager.addEventListener(lis = new Listener());
		APIManager.cmdListeners.put("crypt", lis);
	}

	public static VerificationState verify(String sender, byte[] sig, String content) {
		return verify(sender, sig, content.getBytes());
	}

	public static VerificationState verify(String sender, byte[] sig, byte[] content) {
		PublicKey pubkey = null;
		if (sender.length() != 16 || sender.contains(".") || sender.contains("/") || sender.contains("\\"))
			return VerificationState.ERROR;
		if (!keys.containsKey(sender)) {
			if (new File(Config.CONFIG_DIR + "keys/" + sender + ".pub").exists()) {
				try {
					pubkey = RSAHelper.readPublicKey(Config.CONFIG_DIR + "keys/" + sender + ".pub");
					keys.put(sender, pubkey);
				} catch (Exception e) {
					e.printStackTrace();
					return VerificationState.ERROR;
				}
			} else
				return VerificationState.ERROR;
		} else
			pubkey = keys.get(sender);
		try {
			return RSAHelper.verify(content, sig, pubkey) ? VerificationState.SUCCESS : VerificationState.FAIL;
		} catch (Exception e) {
			e.printStackTrace();
			return VerificationState.ERROR;
		}
	}

	private static class Listener implements APIListener, CommandListener {

		public void onCommand(Buddy b, String command, InputStream is) {
			try {
				if (command.equalsIgnoreCase("crypt")) {
					String subc = Util.readStringTillChar(is, ' ');
					if (subc.equalsIgnoreCase("pubkeydist")) {
						byte[] bb = Util.unescape(Util.readBytesTillChar(is, '\n'));
						PublicKey pubkey = RSAHelper.getPublicKey(bb);
						RSAHelper.writeKey(pubkey, new FileOutputStream(Config.CONFIG_DIR + "keys/" + b.getAddress() + ".pub"));
						Logger.oldOut.println("Got " + b.getAddress() + "'s pubkey");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void onStatusChange(Buddy buddy, byte newStatus, byte oldStatus) { // TODO this probably could/should be done better
			if (oldStatus <= Buddy.HANDSHAKE && newStatus >= Buddy.ONLINE) {// && !new File(Config.CONFIG_DIR + "keys/" + buddy.getAddress() + ".pub").exists()) {
				try {
					synchronized (buddy.OSO_LOCK) {
						OutputStream os = buddy.ourSock.getOutputStream();
						os.write("crypt pubkeydist ".getBytes());
						byte[] bb = Util.escape(keyPair.getPublic().getEncoded());
						os.write(bb);
						os.write("\n".getBytes());
						os.flush();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		public void onProfileNameChange(Buddy buddy, String newName, String oldName) {
		}

		public void onProfileTextChange(Buddy buddy, String newText, String oldText) {
		}

		public void onAddMe(Buddy buddy) {
		}

		public void onMessage(Buddy buddy, String s) {
		}

		public void onNewBuddy(Buddy buddy) {
		}

		public void onBuddyRemoved(Buddy buddy) {
		}
	}
}
