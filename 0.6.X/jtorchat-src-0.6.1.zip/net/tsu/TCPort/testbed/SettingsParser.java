package net.tsu.TCPort.testbed;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

import net.tsu.TCPort.util.ConfigWriter;
import net.tsu.TCPort.util.Regex;

public class SettingsParser {
	private static final String TAG = "(#.*?)[ =]([0-1])([0-1])([0-1])";
	private static final HashMap<String, boolean[]> tagMap = new HashMap<String, boolean[]>();

	public static void main(String[] args) throws Exception {
		Scanner s = new Scanner(new FileInputStream("test.ini"));
		while (s.hasNextLine()) {
			String l = s.nextLine().trim();
			if (l.startsWith("//") || l.length() == 0)
				continue; // ignore
			String[] data;
			if ((data = Regex.getRegArray(l, TAG)) != null) {
				boolean[] res = new boolean[] { Regex.toBoolean(data[2]), Regex.toBoolean(data[3]), Regex.toBoolean(data[4]) };
				tagMap.put(data[1], res);
				System.out.println(data[1] + " " + res[0] + " " + res[1] + " " + res[2]);
			}
		}
		System.out.println(tagMap.entrySet());
		saveSettings();
	}
	
	public static void saveSettings() throws IOException {
		ConfigWriter c = new ConfigWriter(new FileOutputStream("test.ini"));
		c.write("// This file is machine generated, any comments/unknown settings will be removed");
		c.write("// Def: [tag] [alert][minilog][mainlog]");
		for (Entry<String, boolean[]> e : tagMap.entrySet())
			c.write(e.getKey() + " " + Regex.boolToChar(e.getValue()[0]) + Regex.boolToChar(e.getValue()[1]) + Regex.boolToChar(e.getValue()[2]));
		c.close();
	}
	

}
