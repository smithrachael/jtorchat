package net.tsu.TCPort;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class TorLoader {
	private static Process process;
	private static Object loadLock = new Object();

	public static void loadTor() {
//		Logger.log(Logger.SEVERE, "TorLoader", "Not implemented");
		if (System.getProperty("os.name").toLowerCase().indexOf("win") == -1) {
			Logger.log(Logger.NOTICE, "TorLoader", "Error: Not windows.");
			return;
		}
		if (!new File("Tor/tor.exe").exists()) {
			Logger.log(Logger.NOTICE, "TorLoader", "Error: Tor/tor.exe not found.");
			return;
		}
		final TorLoading tl = new TorLoading();
		tl.getProgressBar1().setIndeterminate(true);
		tl.setVisible(true);
		ThreadManager.registerWork(ThreadManager.DAEMON, new Runnable() {

			@Override
			public void run() {
				ProcessBuilder pb = new ProcessBuilder(new String[] {
						"Tor/tor.exe", "-f", "torrc.txt"
				});
				pb.directory(new File("Tor/").getAbsoluteFile());
				System.out.println(new File("Tor/").getAbsolutePath());
				pb.redirectErrorStream(true);
				try {
					process = pb.start();
					Scanner s = new Scanner(process.getInputStream());
					while (s.hasNextLine()) {
						String l = s.nextLine();
						Logger.log(Logger.INFO, "Tor", l);
						if (l.contains("100%")) {
							tl.getProgressBar1().setValue(100);
							synchronized(loadLock) {
								Config.us = new Scanner(new FileInputStream("Tor/hidden_service/hostname")).nextLine().replace(".onion", "");
								Logger.log(Logger.NOTICE, "TorLoader", "Set 'us' to " + Config.us);
								loadLock.notifyAll();
								tl.dispose();
							}
						}
						if (l.contains("Bootstrapped 80%")) {
							tl.getProgressBar1().setIndeterminate(false);
							tl.getProgressBar1().setValue(80);
						}
						if (l.contains("Bootstrapped 85%"))
							tl.getProgressBar1().setValue(85);
						if (l.contains("Bootstrapped 90%"))
							tl.getProgressBar1().setValue(90);
						if (l.contains("Is Tor already running?")) {
							try { // testing other tor
								new Socket("127.0.0.1", Config.SOCKS_PORT);
								synchronized(loadLock) {
									Logger.log(Logger.SEVERE, "TorLoader", "Going to attempt to use other Tor process!");
									Config.us = new Scanner(new FileInputStream("Tor/hidden_service/hostname")).nextLine().replace(".onion", "");
									Logger.log(Logger.NOTICE, "TorLoader", "Set 'us' to " + Config.us);
									loadLock.notifyAll();
									tl.dispose();
								}
							} catch (Exception e) {
								// other tor not on our SOCKS_PORT
								Logger.log(Logger.FATAL, "TorLoader", "Tor exited with " + l + ", failed to use it.");
								throw new RuntimeException(e);
//								System.exit(-1);
							}
						}
						if (l.contains("broken state. Dying.")) {
							Logger.log(Logger.FATAL, "TorLoader", "Tor has died apparently, Ja.");
							throw new RuntimeException("Tor has been slaughtered. (" + l + ")");
						}
					}
				} catch (IOException e) {
					Logger.log(Logger.SEVERE, "TorLoader", e.getLocalizedMessage());
				}
			}
			
		}, "Starting Tor.", "Tor Monitor Thread");
		try {
			synchronized(loadLock) {
				loadLock.wait();
			}
		} catch (InterruptedException e) {
			// do nothing
		}
	}

	public static void cleanUp() {
		synchronized(loadLock) {
			loadLock.notifyAll();
		}
		Logger.log(Logger.INFO, "TorLoader", "ACleaning up.");
		if (process != null) {
			Logger.log(Logger.INFO, "TorLoader", "Cleaning up.");
			process.destroy();
		}
	}

}
