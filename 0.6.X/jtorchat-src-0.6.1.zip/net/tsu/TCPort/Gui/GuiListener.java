package net.tsu.TCPort.Gui;

import net.tsu.TCPort.Buddy;

public interface GuiListener {
	public void onCommand(Buddy buddy, String s);
}
