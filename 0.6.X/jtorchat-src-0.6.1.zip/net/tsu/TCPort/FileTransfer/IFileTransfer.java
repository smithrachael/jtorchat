package net.tsu.TCPort.FileTransfer;


public interface IFileTransfer {
	public void close();
}
