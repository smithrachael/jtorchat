package net.tsu.TCPort;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import net.tsu.TCPort.util.Regex;

public class Config {
	public static String VERSION = "0.6";
	public static boolean TESTING;
	public static String BASE_DIR = "";
	public static String CONFIG_DIR = "Config/";
	public static int SOCKS_PORT; // = TESTING ? 11599 : 11157;
	public static int LOCAL_PORT; // = TESTING ? 8974 : 8975;
	public static String us; // = "whi3dc7xmy7bqg7w"; // value defined here only used when TESTING == true
	
	public static final Properties prop;
	public static final boolean loadTor;
	static {
//		Matcher m = Pattern.compile("/home/.*?/").matcher(new File(".").getAbsolutePath());
//		if (m.matches()) // pretty dodgy but should work
//			BASE_DIR = ".JTorchat/";

		String x = System.getProperty("java.class.path");
		for (String s : x.split(";")) // prioritize finding the jar
			if (Regex.match(".*?[/\\\\]{0,1}jtorchat.*?\\.jar", s.toLowerCase())) {
				BASE_DIR = new File(s).isDirectory() ? new File(s).getPath() : new File(s).getParent();
				break;
			}
		if (BASE_DIR == null || BASE_DIR.length() == 0)
			for (String s : x.split(";"))
				if (!Regex.match("bin(?!.)", s.toLowerCase())) { // dodgy ~
					BASE_DIR = new File(s).isDirectory() ? new File(s).getParent() : new File(s).getParent();
					break;
				} else if (!Regex.match("build(?!.)", s.toLowerCase())) { // dodgy ~
					BASE_DIR = new File(s).isDirectory() ? new File(s).getParent() : new File(s).getParent();
					break;
				}
		if (BASE_DIR == null)
			BASE_DIR = "";
		if (BASE_DIR.length() > 0) {
			if (!BASE_DIR.endsWith("/") && !BASE_DIR.endsWith("\\"))
				BASE_DIR += "/";
			Logger.log(Logger.NOTICE, "Config", "Using " + BASE_DIR + " as BASE_DIR");
			CONFIG_DIR = BASE_DIR + CONFIG_DIR;
		}
		new File(CONFIG_DIR).mkdirs();
		prop = new Properties();
		try {
			prop.load(new FileInputStream(CONFIG_DIR + "settings.ini"));
		} catch (FileNotFoundException e) {
//			e.printStackTrace();
		} catch (IOException e) {
//			e.printStackTrace();
		}
		
		if (prop.get("TESTING") != null && prop.get("TESTING").equals("true")) {
			TESTING = true;
			Logger.log(Logger.NOTICE, "Config", "Testing mode.");
		} else
			TESTING = false;
		
		if (!TESTING) {
			us = assign("ourId", null, prop);
			if (System.getProperty("os.name").toLowerCase().indexOf("win") >= 0) {
				SOCKS_PORT = assignInt("SOCKS_PORT", 11157, prop);
				LOCAL_PORT = assignInt("LOCAL_PORT", 8975, prop);
				loadTor = Boolean.parseBoolean(assign("loadTor", "true", prop));
			} else {
				SOCKS_PORT = assignInt("SOCKS_PORT", -1, prop);
				LOCAL_PORT = assignInt("LOCAL_PORT", -1, prop);
				loadTor = false;
			}
		} else {
			SOCKS_PORT = 11599;
			LOCAL_PORT = 8974;
			loadTor = false;
			us = assign("testingId", null, prop);
		}
		
		TCPort.profile_name = assign("profile_name", null, prop);
		TCPort.profile_text = assign("profile_text", null, prop);
		
		Logger.log(Logger.INFO, "Config", "Using " + SOCKS_PORT + " as socks port and " + LOCAL_PORT + " as local port.");
	}
	
	public static void reloadSettings() { // reloads almost all settings

		new File(CONFIG_DIR).mkdirs();
		prop.clear();
		try {
			prop.load(new FileInputStream(CONFIG_DIR + "settings.ini"));
		} catch (FileNotFoundException e) {
			System.err.println(e.getLocalizedMessage());
		} catch (IOException e) {
			System.err.println(e.getLocalizedMessage());
		}
		
		if (prop.get("TESTING") != null && prop.get("TESTING").equals("true")) {
			TESTING = true;
			Logger.log(Logger.NOTICE, "Config", "Testing mode.");
		} else
			TESTING = false;
		
		if (!TESTING) {
			SOCKS_PORT = assignInt("SOCKS_PORT", 11157, prop);
			LOCAL_PORT = assignInt("LOCAL_PORT", 8975, prop);
			us = assign("ourId", null, prop);
		} else {
			VERSION += " dev";
			SOCKS_PORT = 11599;
			LOCAL_PORT = 8974;
			us = assign("testingId", null, prop);
		}
		
		TCPort.profile_name = assign("profile_name", null, prop);
		TCPort.profile_text = assign("profile_text", null, prop);
		
		Logger.log(Logger.INFO, "Config", "Using " + SOCKS_PORT + " as socks port and " + LOCAL_PORT + " as local port.");
	}
	
	public static final int DEAD_CONNECTION_TIMEOUT = 240;
	public static final int KEEPALIVE_INTERVAL = (int) (Math.random()*120); //120;
	public static final int MAX_UNANSWERED_PINGS = 4;
	public static final int CONNECT_TIMEOUT = 70;
	
	public static final String CLIENT = "JTC [T2]";
	
	private static int assignInt(String string, int def, Properties prop) {
		String x = (String) prop.get(string);
		int i = def;
		if (x != null)
			try {
				i = Integer.parseInt(x);
			} catch (NumberFormatException nfe) {
				System.err.println(nfe.getLocalizedMessage());
			}
		if (i == def)
			Logger.log(Logger.NOTICE, "Config", string + " not defined using " + def);
		return i;
	}

	public static String assign(String string, String s, Properties prop) {
		String x = (String) prop.get(string);
		String ret = s;
		if (x != null)
			ret = x;
		if (ret == null && s == null || s != null && ret != null && ret.equals(s))
			Logger.log(Logger.NOTICE, "Config", string + " not defined using " + s);
		return ret;
	}
	
}
