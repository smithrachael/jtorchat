package net.tsu.TCPort.Gui;

import java.awt.Color;
import java.awt.Container;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.GroupLayout;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import net.tsu.TCPort.Buddy;
import net.tsu.TCPort.Config;

/**
 * @author Tsu
 */
@SuppressWarnings("serial")
public class ChatWindow extends JFrame {
	private static DropTargetListener dropListener; 
	private Buddy b;
	private Style timestampStyle;
	private Style myNameStyle;
	private Style theirNameStyle;

	// private Style normalStyle;
	
	static {
		try {
			Class<?> c = Class.forName("net.tsu.TCPort.FileTransfer.Drag");
			dropListener = (DropTargetListener) c.newInstance();
		} catch (Exception e) {
			// ignored
			e.printStackTrace();
		}
	}

	public ChatWindow(Buddy b) {
		this.b = b;
		initComponents();
	
		if (dropListener != null)
			new DropTarget(textPane1, DnDConstants.ACTION_COPY_OR_MOVE, dropListener, true, null);
		
		System.out.println(textPane1.getDocument().getClass().getCanonicalName());
		textPane1.setEditable(false);
		// textPane1.setWrapStyleWord(true); // not needed anymore
		// textPane1.setLineWrap(true); // not needed anymore
		textArea4.setWrapStyleWord(true);
		textArea4.setLineWrap(true);
		addWindowFocusListener(new WindowAdapter() {

			public void windowGainedFocus(WindowEvent e) {
				textArea4.requestFocusInWindow();
			}
		});
		timestampStyle = ((StyledDocument) textPane1.getDocument()).addStyle("Time Stamp", null);
		StyleConstants.setForeground(timestampStyle, Color.gray.darker());
		myNameStyle = ((StyledDocument) textPane1.getDocument()).addStyle("Me", null);
		StyleConstants.setForeground(myNameStyle, Color.blue.darker());
		theirNameStyle = ((StyledDocument) textPane1.getDocument()).addStyle("Them", null);
		StyleConstants.setForeground(theirNameStyle, Color.red.darker());
		textPane1.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				textArea4.dispatchEvent(e);
				textArea4.requestFocusInWindow();
			}

			@Override
			public void keyPressed(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
			}

		});
	}

	private void textArea4KeyReleased(KeyEvent e) {
		if (e.getKeyCode() == 10) { // enter
			if (!textArea4.getText().trim().equals("")) {
				try {
					String msg = textArea4.getText().trim().replaceAll("\n", "\\\\n").replaceAll("\n", "\\\\n").replaceAll("\r", "");
					if (msg.startsWith("/") && Gui.getInstance().cmdListeners.containsKey(msg.split(" ")[0].substring(1))) {
						Gui.getInstance().cmdListeners.get(msg.split(" ")[0].substring(1)).onCommand(b, msg);
					} else {
						// textPane1
						append("Time Stamp", "(" + getTime() + ") ");
						append("Me", "Me: ");
						append("Plain", textArea4.getText().trim() + "\n");
						// textPane1.insert("(" + getTime() + ") Me: "
						// + textArea4.getText().trim() + "\n", textPane1
						// .getText().length());
						textPane1.setCaretPosition(textPane1.getDocument().getLength());
						textArea4.requestFocusInWindow();
						// System.out.println(msg + " | " + textArea2.getText());
						if (msg.trim().endsWith("\\\\n")) {
							// System.out.println("s");
							msg.substring(0, msg.length() - 6);
						}
						if (b.isFullyConnected())
							b.sendMessage(msg);
						else {
							FileOutputStream fos = new FileOutputStream(Config.BASE_DIR + "OfflineMsgs/" + b.getAddress() + ".txt", true);
							fos.write((msg + "\n").getBytes());
							fos.close();
						}
					}
					textArea4.setText("");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			} else {
				textArea4.setText("");
				// clear the text area anyways
			}
		}
	}

	private void textArea4KeyPressed(KeyEvent e) {
		if (e.getKeyCode() == 10) // line break - \n
			e.consume();
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY //GEN-BEGIN:initComponents
		scrollPane3 = new JScrollPane();
		textPane1 = new JTextPane();
		scrollPane4 = new JScrollPane();
		textArea4 = new JTextArea();

		// ======== this ========
		Container contentPane = getContentPane();

		// ======== scrollPane3 ========
		{
			scrollPane3.setViewportView(textPane1);
		}

		// ======== scrollPane4 ========
		{

			// ---- textArea4 ----
			textArea4.addKeyListener(new KeyAdapter() {

				@Override
				public void keyPressed(KeyEvent e) {
					textArea4KeyPressed(e);
				}

				@Override
				public void keyReleased(KeyEvent e) {
					textArea4KeyReleased(e);
				}
			});
			scrollPane4.setViewportView(textArea4);
		}

		GroupLayout contentPaneLayout = new GroupLayout(contentPane);
		contentPane.setLayout(contentPaneLayout);
		contentPaneLayout.setHorizontalGroup(contentPaneLayout.createParallelGroup().addComponent(scrollPane4, GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE).addComponent(scrollPane3, GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE));
		contentPaneLayout.setVerticalGroup(contentPaneLayout.createParallelGroup().addGroup(GroupLayout.Alignment.TRAILING,
				contentPaneLayout.createSequentialGroup().addComponent(scrollPane3, GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(scrollPane4, GroupLayout.PREFERRED_SIZE, 59, GroupLayout.PREFERRED_SIZE)));
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization //GEN-END:initComponents
	}

	public void append(String style, String text) {
		try {
			StyledDocument doc = (StyledDocument) textPane1.getDocument(); // Create a style object and then set the style attributes
			doc.insertString(doc.getLength(), text, doc.getStyle(style));
		} catch (BadLocationException ble) {
			ble.printStackTrace();
		}
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY //GEN-BEGIN:variables
	private JScrollPane scrollPane3;
	private JTextPane textPane1;
	private JScrollPane scrollPane4;
	private JTextArea textArea4;

	// JFormDesigner - End of variables declaration //GEN-END:variables

	public JEditorPane getTextPane1() {
		return textPane1;
	}

	public JTextArea getTextArea4() {
		return textArea4;
	}

	public static String getTime() {
		return new SimpleDateFormat("h:mm:ss").format(new Date());
		// return Calendar.getInstance().get(Calendar.HOUR) + ":" + Calendar.getInstance().get(Calendar.MINUTE) + ":" + Calendar.getInstance().get(Calendar.SECOND);
	}
	
	public Buddy getBuddy() {
		return b;
	}
}
