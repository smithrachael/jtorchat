package net.tsu.TCPort;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;


public class BuddyList {
	public static HashMap<String, Buddy> buds = new HashMap<String, Buddy>();
	
	
	public static void addBuddy(Buddy b) {
		BuddyList.buds.put(b.getAddress(), b);
		APIManager.fireNewBuddy(b);
	}
	
	public static void loadBuddies() throws FileNotFoundException {
//		Logger.log(Logger.INFO, "BuddyList loader", Config.CONFIG_DIR + "bl.txt");
		Scanner s = new Scanner(new FileInputStream(Config.CONFIG_DIR + "bl.txt"));
		Random r = new Random();
		while (s.hasNextLine()) {
			String l = s.nextLine();
			// from 0 to 16 is address, 17 onwards is name
			if (buds.containsKey(l.substring(0, 16)))
				try {
					buds.remove(l.substring(0, 16)).disconnect();
				} catch (IOException e) {
					System.err.println("Error disconnecting buddy: " + e.getLocalizedMessage());
				}
			if (l.length() > 16)
				new Buddy(l.substring(0, 16), l.substring(17)).reconnectAt = System.currentTimeMillis() + 15000 + r.nextInt(30000); //.connect();
			else
				new Buddy(l.substring(0, 16), null).reconnectAt = System.currentTimeMillis() + 15000 + r.nextInt(30000); //.connect();
		}
	}
	
	public static void saveBuddies() throws IOException {
		FileOutputStream fos = new FileOutputStream(Config.CONFIG_DIR + "bl.txt");
		for (Buddy b : buds.values())
			fos.write((b.getAddress() + " " + ((b.getProfile_name() != null && b.getProfile_name().length() > 0) ? b.getProfile_name() : (b.getName() != null && b.getName().length() > 0) ? b.getName() : "") + "\n").getBytes());
		fos.close();
	}

}
