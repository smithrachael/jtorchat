package net.tsu.TCPort.Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;

@SuppressWarnings("serial")
public class Log extends JFrame {
	public static final Log instance;
	public Log() {
		initComponents();
		setSize(755, 402);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		textPane1.setEditable(false);
		DefaultStyledDocument d = (DefaultStyledDocument) textPane1.getDocument();
		Style timestampStyle = d.addStyle("Time Stamp", null);
	    StyleConstants.setForeground(timestampStyle, Color.gray.darker());
	    Style theirNameStyle = d.addStyle("Err", null);
	    StyleConstants.setForeground(theirNameStyle, Color.red.darker());
	    Style classc = d.addStyle("Class-c", null);
	    StyleConstants.setForeground(classc, Color.green.darker());
	    Style classt = d.addStyle("Class-t", null);
	    StyleConstants.setForeground(classt, Color.green.darker().darker().darker());
	}
	
	static {
		Gui.setLAF("Nimbus");
		instance = new Log();
//		instance.setVisible(true);
	}

	private static Object LOCK = new Object(); 
	
	public static void append(String text, String style) {
		synchronized(LOCK) {
			DefaultStyledDocument d = (DefaultStyledDocument) instance.textPane1.getDocument();
			try {
				d.insertString(d.getLength(), text, style == null ? null : d.getStyle(style));
				instance.textPane1.setCaretPosition(d.getLength());
			} catch (BadLocationException ble) {
				ble.printStackTrace();
			}
		}
	}

	public static void updateErr(String s) {
		synchronized(LOCK) {
			DefaultStyledDocument d = (DefaultStyledDocument) instance.textPane1.getDocument();
			try {
				d.insertString(d.getLength(), s, d.getStyle("Err"));
				instance.textPane1.setCaretPosition(d.getLength());
			} catch (BadLocationException ble) {
				ble.printStackTrace();
			}
		}
	}

	public static void updateOut(String s) {
		synchronized(LOCK) {
			DefaultStyledDocument d = (DefaultStyledDocument) instance.textPane1.getDocument();
			try {
				d.insertString(d.getLength(), s, null);
				instance.textPane1.setCaretPosition(d.getLength());
			} catch (BadLocationException ble) {
				ble.printStackTrace();
			}
		}
	}
	
	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		scrollPane1 = new JScrollPane();
		textPane1 = new JTextPane();

		//======== this ========
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout(8, 8));

		//======== scrollPane1 ========
		{
			scrollPane1.setViewportView(textPane1);
		}
		contentPane.add(scrollPane1, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	private JScrollPane scrollPane1;
	private JTextPane textPane1;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
